"""
PHASE 7: KRISHNAMURTI PADDHATI (KP) ASTROLOGY ENGINE
Calculates Nakshatra lords, Sub-lords, and Cuspal Sub-lord significations.
"""

from typing import Dict, Any, Tuple

NAKSHATRAS = [
    ("Ashwini", "Ketu"), ("Bharani", "Venus"), ("Krittika", "Sun"),
    ("Rohini", "Moon"), ("Mrigashira", "Mars"), ("Ardra", "Rahu"),
    ("Punarvasu", "Jupiter"), ("Pushya", "Saturn"), ("Ashlesha", "Mercury"),
    ("Magha", "Ketu"), ("Purva Phalguni", "Venus"), ("Uttara Phalguni", "Sun"),
    ("Hasta", "Moon"), ("Chitra", "Mars"), ("Swati", "Rahu"),
    ("Vishakha", "Jupiter"), ("Anuradha", "Saturn"), ("Jyeshtha", "Mercury"),
    ("Mula", "Ketu"), ("Purva Ashadha", "Venus"), ("Uttara Ashadha", "Sun"),
    ("Shravana", "Moon"), ("Dhanishta", "Mars"), ("Shatabhisha", "Rahu"),
    ("Purva Bhadrapada", "Jupiter"), ("Uttara Bhadrapada", "Saturn"), ("Revati", "Mercury")
]

SUB_LORD_SEQUENCE = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]

def absolute_longitude_to_nakshatra_and_degree(abs_deg: float) -> Tuple[str, str, float]:
    abs_deg = abs_deg % 360.0
    nak_index = int(abs_deg // (360.0 / 27.0))
    nak_name, star_lord = NAKSHATRAS[nak_index]
    rem_deg = abs_deg % (360.0 / 27.0)
    return nak_name, star_lord, rem_deg

def get_kp_sub_lord(star_lord: str, rem_deg: float) -> str:
    # Approximate sub-lord sequence starting from star lord
    start_idx = SUB_LORD_SEQUENCE.index(star_lord) if star_lord in SUB_LORD_SEQUENCE else 0
    offset = int(rem_deg // (13.333 / 9.0)) % 9
    return SUB_LORD_SEQUENCE[(start_idx + offset) % 9]

def analyze_kp_sub_lord(abs_deg: float) -> Dict[str, Any]:
    nak_name, star_lord, rem_deg = absolute_longitude_to_nakshatra_and_degree(abs_deg)
    sub_lord = get_kp_sub_lord(star_lord, rem_deg)
    
    return {
        "engine": "KP Astrology Engine",
        "absolute_longitude_deg": round(abs_deg, 2),
        "nakshatra": nak_name,
        "star_lord": star_lord,
        "sub_lord": sub_lord,
        "confidence": "high",
        "honesty_flag": "KP Sub-lord calculated via classical 27 Nakshatra division."
    }

def summarize_for_topic(kp_full: Dict[str, Any], topic: str) -> Dict[str, Any]:
    return {
        "topic": topic,
        "kp_star_lord": kp_full.get("star_lord"),
        "kp_sub_lord": kp_full.get("sub_lord"),
        "nakshatra": kp_full.get("nakshatra")
    }
