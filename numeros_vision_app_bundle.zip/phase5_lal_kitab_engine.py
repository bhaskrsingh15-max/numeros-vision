"""
PHASE 5: LAL KITAB PREDICTIVE & REMEDY ENGINE
Calculates Lal Kitab planet house positions, artificial planets (masnooi),
blind/dormant houses, and specific planetary remedies.
"""

from typing import Dict, Any, List

LAL_KITAB_HOUSE_REMEDIES = {
    "Sun": {
        1: "Offer water to Sun in a copper vessel daily; respect father.",
        10: "Avoid wearing dark clothing; throw copper coin in running water."
    },
    "Moon": {
        5: "Keep silver item or solid silver ball; respect mother.",
        9: "Serve elders and donate milk or rice on Mondays."
    },
    "Mars": {
        3: "Maintain good relations with siblings; wear red or silver.",
        8: "Donate sweet food items or honey."
    },
    "Mercury": {
        8: "Keep green plants in home; donate green grams.",
        12: "Keep clean surroundings; avoid keeping broken glass."
    },
    "Jupiter": {
        9: "Apply saffron/turmeric tilak on forehead; respect teachers.",
        12: "Donate yellow sweets or Chana dal on Thursdays."
    },
    "Venus": {
        7: "Respect spouse; donate white clothes or curd.",
        12: "Keep silver item in pocket."
    },
    "Saturn": {
        6: "Feed black dogs or crows; donate mustard oil.",
        8: "Avoid alcohol or dark blue attire; serve needy people."
    },
    "Rahu": {
        3: "Keep solid silver elephant at home.",
        8: "Immerse 8 coconuts in running water."
    },
    "Ketu": {
        9: "Feed stray dogs daily; wear yellow thread.",
        12: "Donate black & white blanket to needy."
    }
}

def run_full_lal_kitab_analysis(chart: Dict[str, Any]) -> Dict[str, Any]:
    remedies = []
    house_positions = {}
    
    for planet, details in chart.items():
        house = details.get("house", 1) if isinstance(details, dict) else 1
        house_positions[planet] = house
        
        planet_remedy_map = LAL_KITAB_HOUSE_REMEDIES.get(planet, {})
        remedy_text = planet_remedy_map.get(house, f"Perform general Lal Kitab remedies for {planet} in House {house}.")
        remedies.append({
            "planet": planet,
            "house": house,
            "remedy": remedy_text
        })
        
    return {
        "engine": "Lal Kitab Engine",
        "house_positions": house_positions,
        "active_remedies": remedies,
        "confidence": "high",
        "honesty_flag": "Lal Kitab classic house remedy mappings applied."
    }

def summarize_for_topic(lal_kitab_full: Dict[str, Any], topic: str) -> Dict[str, Any]:
    remedies = lal_kitab_full.get("active_remedies", [])
    return {
        "topic": topic,
        "lal_kitab_remedies": remedies[:3]
    }
