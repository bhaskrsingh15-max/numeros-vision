"""
PHASE 2: D60 (SHASHTIAMSHA) DEITY & KARMIC ROOT ENGINE
Calculates exact 1/60th micro-arc (0°30') for each planet and the Ascendant,
assigns classical Parashari Shashtiamsha deities (Odd sign direct 1-60, Even sign reverse 60-1),
and classifies the soul's root karmic disposition (Shubha/Benefic vs Krura/Malefic).
"""

D60_DEITIES = [
    {"no": 1, "name": "Ghora", "nature": "Malefic"},
    {"no": 2, "name": "Rakshasa", "nature": "Malefic"},
    {"no": 3, "name": "Deva", "nature": "Benefic"},
    {"no": 4, "name": "Kubera", "nature": "Benefic"},
    {"no": 5, "name": "Yaksha", "nature": "Benefic"},
    {"no": 6, "name": "Kinnara", "nature": "Benefic"},
    {"no": 7, "name": "Bhrashta", "nature": "Malefic"},
    {"no": 8, "name": "Kulaghna", "nature": "Malefic"},
    {"no": 9, "name": "Garala", "nature": "Malefic"},
    {"no": 10, "name": "Vahnipatha", "nature": "Malefic"},
    {"no": 11, "name": "Maya", "nature": "Malefic"},
    {"no": 12, "name": "Purishaka", "nature": "Malefic"},
    {"no": 13, "name": "Apampati", "nature": "Benefic"},
    {"no": 14, "name": "Marut", "nature": "Benefic"},
    {"no": 15, "name": "Kaala", "nature": "Malefic"},
    {"no": 16, "name": "Sarpa", "nature": "Malefic"},
    {"no": 17, "name": "Amrita", "nature": "Benefic"},
    {"no": 18, "name": "Indu", "nature": "Benefic"},
    {"no": 19, "name": "Mridu", "nature": "Benefic"},
    {"no": 20, "name": "Komala", "nature": "Benefic"},
    {"no": 21, "name": "Heramba", "nature": "Benefic"},
    {"no": 22, "name": "Brahma", "nature": "Benefic"},
    {"no": 23, "name": "Vishnu", "nature": "Benefic"},
    {"no": 24, "name": "Maheshwara", "nature": "Benefic"},
    {"no": 25, "name": "Deva", "nature": "Benefic"},
    {"no": 26, "name": "Ardra", "nature": "Benefic"},
    {"no": 27, "name": "Kalanasa", "nature": "Benefic"},
    {"no": 28, "name": "Kshiteesa", "nature": "Benefic"},
    {"no": 29, "name": "Kamalakara", "nature": "Benefic"},
    {"no": 30, "name": "Gulika", "nature": "Malefic"},
    {"no": 31, "name": "Mrityu", "nature": "Malefic"},
    {"no": 32, "name": "Kaala", "nature": "Malefic"},
    {"no": 33, "name": "Davagni", "nature": "Malefic"},
    {"no": 34, "name": "Ghora", "nature": "Malefic"},
    {"no": 35, "name": "Yama", "nature": "Malefic"},
    {"no": 36, "name": "Kantaka", "nature": "Malefic"},
    {"no": 37, "name": "Suddha", "nature": "Benefic"},
    {"no": 38, "name": "Amrita", "nature": "Benefic"},
    {"no": 39, "name": "Purnachandra", "nature": "Benefic"},
    {"no": 40, "name": "Vishadagdha", "nature": "Malefic"},
    {"no": 41, "name": "Kulanasa", "nature": "Malefic"},
    {"no": 42, "name": "Vamshakshaya", "nature": "Malefic"},
    {"no": 43, "name": "Utpata", "nature": "Malefic"},
    {"no": 44, "name": "Kaala", "nature": "Malefic"},
    {"no": 45, "name": "Saumya", "nature": "Benefic"},
    {"no": 46, "name": "Komala", "nature": "Benefic"},
    {"no": 47, "name": "Sheetala", "nature": "Benefic"},
    {"no": 48, "name": "Karaladamshtra", "nature": "Malefic"},
    {"no": 49, "name": "Chandramukhi", "nature": "Benefic"},
    {"no": 50, "name": "Praveena", "nature": "Benefic"},
    {"no": 51, "name": "Kalapavaka", "nature": "Malefic"},
    {"no": 52, "name": "Dandayudha", "nature": "Malefic"},
    {"no": 53, "name": "Nirmala", "nature": "Benefic"},
    {"no": 54, "name": "Saumya", "nature": "Benefic"},
    {"no": 55, "name": "Krura", "nature": "Malefic"},
    {"no": 56, "name": "Atisheetala", "nature": "Benefic"},
    {"no": 57, "name": "Amrita", "nature": "Benefic"},
    {"no": 58, "name": "Payodhi", "nature": "Benefic"},
    {"no": 59, "name": "Bhramana", "nature": "Malefic"},
    {"no": 60, "name": "Chandrarekha", "nature": "Benefic"}
]

ZODIAC_SIGNS = [
    "Aries", "Taurus", "Gemini", "Cancer",
    "Leo", "Virgo", "Libra", "Scorpio",
    "Sagittarius", "Capricorn", "Aquarius", "Pisces"
]

def calculate_d60_for_planet(planet_name: str, sign_name: str, degree_in_sign: float) -> dict:
    sign_idx = ZODIAC_SIGNS.index(sign_name) if sign_name in ZODIAC_SIGNS else 0
    # Each amsha is 0.5 degrees (30 arcminutes)
    amsha_num = min(60, max(1, int(degree_in_sign * 2.0) + 1))
    
    # Odd signs count direct 1->60, Even signs reverse 60->1
    is_odd = (sign_idx % 2 == 0)
    deity_idx = amsha_num if is_odd else (61 - amsha_num)
    deity_info = D60_DEITIES[deity_idx - 1]

    # Calculate D60 sign placement in divisional chart
    total_zodiac_degree = (sign_idx * 30.0) + degree_in_sign
    d60_total_degree = (total_zodiac_degree * 60.0) % 360.0
    d60_sign_index = int(d60_total_degree / 30.0)
    d60_sign_degree = d60_total_degree % 30.0

    return {
        "planet": planet_name,
        "natal_sign": sign_name,
        "natal_degree": round(degree_in_sign, 2),
        "d60_amsha_part": amsha_num,
        "deity_number": deity_info["no"],
        "deity_name": deity_info["name"],
        "karmic_nature": deity_info["nature"],
        "is_benefic_root": (deity_info["nature"] == "Benefic"),
        "d60_sign": ZODIAC_SIGNS[d60_sign_index],
        "d60_degree": round(d60_sign_degree, 2)
    }

def run_full_d60_analysis(chart_dict: dict) -> dict:
    placements = {}
    benefic_count = 0
    total_count = 0

    for planet, data in chart_dict.items():
        if isinstance(data, dict) and "sign" in data and "degree" in data:
            info = calculate_d60_for_planet(planet, data["sign"], float(data["degree"]))
            placements[planet] = info
            total_count += 1
            if info["is_benefic_root"]:
                benefic_count += 1

    ratio_pct = round((benefic_count / total_count) * 100, 1) if total_count else 50.0

    return {
        "engine": "Phase 2 D60 Karmic Root Engine",
        "placements": placements,
        "benefic_deity_count": benefic_count,
        "total_evaluated": total_count,
        "karmic_benefic_ratio": f"{benefic_count}/{total_count}",
        "karmic_strength_pct": ratio_pct,
        "karmic_summary": (
            "Dominant auspicious karmic roots (high benefic devatas)"
            if ratio_pct >= 60 else
            "Mixed past-life karmic burdens requiring remedial discipline"
            if ratio_pct <= 40 else
            "Balanced karmic root distribution"
        )
    }
