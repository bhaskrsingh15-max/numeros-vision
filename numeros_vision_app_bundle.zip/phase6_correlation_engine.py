"""
PHASE 6: CORRELATION, CONSENSUS & CHARM AI SYNTHESIS ENGINE
Powers 'Charm AI' (Numeros Vision) — Designed on the Melooha 'Vaani' Architectural Model.

Core Operational Flow:
1. Deterministic Calculation Ingestion (Phases 1-8)
2. Normalized Findings & Conflict Detection (Verdicts, Timings, Actions)
3. Domain-Specific Priority Resolution (KP for timing, BNN for pattern, D60 for karmic roots)
4. 8-Tier Remedy Safety Engine (Strict gemstone gating, prioritizing routine & daan)
5. Charm AI Synthesis Packager (Structured 9-Section Grounded Explanation + Conversational Prompt)
"""

from typing import Dict, Any, List, Set
from datetime import datetime, timedelta

# Domain-specific priority order (highest authority first)
PRIORITY_MATRIX = {
    "career":   ["kp_astrology", "bnn", "d60_astrology", "numerology", "lal_kitab"],
    "marriage": ["kp_astrology", "bnn", "d60_astrology", "name_numerology", "lal_kitab"],
    "wealth":   ["bnn", "kp_astrology", "d60_astrology", "numerology", "lal_kitab"],
    "health":   ["d60_astrology", "bnn", "lal_kitab", "numerology"],
    "property": ["kp_astrology", "d60_astrology", "bnn", "lal_kitab"],
    "general":  ["numerology", "bnn", "d60_astrology", "lal_kitab"]
}

# 8-Tier Remedy Safety Hierarchy
SAFE_REMEDIES = {"ROUTINE", "DISCIPLINE", "SEVA", "MANTRA", "DAAN"}
REVIEW_REMEDIES = {"RUDRAKSHA", "UPASANA"}
GATED_REMEDIES = {"GEMSTONE"}

CHARM_AI_SYSTEM_PROMPT = """You are 'Charm AI', the official conversational intelligence of Numeros Vision (Tagline: 'Anviel Every Charm').
You provide grounded, empathetic, and actionable guidance based strictly on the verified multi-system calculations provided in your context.

CORE RULES:
1. NEVER hallucinate or invent planetary placements, dasha dates, karmic devatas, or predictions.
2. If systems disagree (e.g., KP indicates delay while BNN indicates long-term growth), explain the difference honestly in plain language. Never declare one classical system 'wrong'.
3. Always adopt a calm, supportive, and non-fatalistic counseling tone. Avoid fear-mongering.
4. Gemstones are strictly prohibited unless the safety check explicitly clears a functional benefic. Recommend routine, seva, mantras, or daan first.
5. Format your response following the 9-Section Charm AI Framework.
"""

def detect_conflicts(findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Detects verdict, timing, and action conflicts across engines."""
    conflicts = []
    
    # 1. Verdict Conflicts
    verdicts = {f["engine"]: f["verdict"] for f in findings if "verdict" in f}
    unique_verdicts = set(verdicts.values())
    if len(unique_verdicts) > 1:
        conflicts.append({
            "type": "VERDICT_CONFLICT",
            "description": "Engines disagree on the directional recommendation.",
            "breakdown": verdicts
        })

    # 2. Timing Conflicts
    timings = {f["engine"]: f["timing"] for f in findings if f.get("timing")}
    if len(timings) > 1:
        conflicts.append({
            "type": "TIMING_CONFLICT",
            "description": "Engines identify different maturity windows.",
            "breakdown": timings
        })

    # 3. Action Disjointness
    action_sets = [set(f.get("actions", [])) for f in findings if f.get("actions")]
    if action_sets and not set.intersection(*action_sets):
        conflicts.append({
            "type": "ACTION_VARIANCE",
            "description": "Engines advise different immediate next steps."
        })

    return conflicts

def resolve_remedies(findings: List[Dict[str, Any]], chart_context: Dict[str, Any]) -> Dict[str, Any]:
    """Applies the 8-Tier Safety Ladder to prescribe non-harmful remedies."""
    collected_allowed: List[Set[str]] = [set(f.get("remedies_allowed", [])) for f in findings if f.get("remedies_allowed")]
    
    # Find common safe remedies
    if collected_allowed:
        common = set.intersection(*collected_allowed)
        safe_common = list(common.intersection(SAFE_REMEDIES))
    else:
        safe_common = []

    if not safe_common:
        safe_common = ["ROUTINE", "DISCIPLINE", "MANTRA"]

    # Specific actionable descriptions
    remedy_details = []
    if "ROUTINE" in safe_common or "DISCIPLINE" in safe_common:
        remedy_details.append({
            "category": "Behavioral & Habit",
            "action": "Maintain structured waking times and journal daily decisions to anchor mental clarity.",
            "risk_level": "None (Safe for all charts)"
        })
    if "MANTRA" in safe_common:
        remedy_details.append({
            "category": "Sacred Sound / Mantra",
            "action": "Chant Gayatri Mantra or the planetary Beej mantra corresponding to your driver planet.",
            "risk_level": "Harmonizing frequency (Safe)"
        })
    if "DAAN" in safe_common or "SEVA" in safe_common:
        remedy_details.append({
            "category": "Seva / Karma Correction",
            "action": "Support food distribution or donate clean water/grains on Saturdays or Wednesdays.",
            "risk_level": "Karmic debt neutralization (Safe)"
        })

    return {
        "safety_status": "APPROVED_SAFE_REMEDIES",
        "recommended_remedies": remedy_details,
        "gemstone_verdict": "BLOCKED_BY_SAFETY_FIREWALL",
        "gemstone_rationale": "Gemstones act as direct energy amplifiers. Per Parashara and Charm AI safety rules, gemstones require independent functional benefic review to avoid amplifying malefic houses."
    }

def run_correlated_prediction(topic: str, **kwargs) -> Dict[str, Any]:
    """
    Main Entry Point: Integrates multi-layer findings, applies conflict detection,
    resolves consensus via priority matrix, and compiles the Charm AI Explanation Packet.
    """
    findings: List[Dict[str, Any]] = []

    # 1. Parse Phase 1 (Numerology)
    p1 = kwargs.get("phase1_result")
    if p1:
        drv = p1.get("driver")
        cnd = p1.get("conductor")
        friendly = p1.get("friendly_numbers", [])
        is_harmonious = cnd in friendly or drv == cnd
        findings.append({
            "engine": "numerology",
            "label": "Chaldean/Vedic Numerology (Phase 1)",
            "verdict": "STRONG_YES" if is_harmonious else "CONDITIONAL_YES",
            "statement": f"Driver {drv} and Conductor {cnd} are in {'harmonic resonance' if is_harmonious else 'creative tension'}.",
            "confidence": 0.85,
            "actions": ["LEVERAGE_STRENGTHS", "EXPAND_NETWORK"],
            "remedies_allowed": ["ROUTINE", "MANTRA"]
        })

    # 2. Parse Phase 2 (D60 Karmic Roots)
    p2 = kwargs.get("phase2_result")
    if p2:
        k_pct = p2.get("karmic_strength_pct", 50.0)
        k_ratio = p2.get("karmic_benefic_ratio", "N/A")
        is_high = k_pct >= 60.0
        findings.append({
            "engine": "d60_astrology",
            "label": "D60 Shashtiamsha Karmic Root (Phase 2)",
            "verdict": "YES" if is_high else ("DELAY" if k_pct <= 40.0 else "CONDITIONAL_YES"),
            "statement": f"D60 Devata Analysis: {k_ratio} planets sit in auspicious Shubha amshas ({k_pct}% karmic support).",
            "confidence": 0.88,
            "actions": ["ALIGN_WITH_ROOT_KARMA", "PRACTICE_PATIENCE"],
            "remedies_allowed": ["MANTRA", "SEVA"]
        })

    # 3. Parse Phase 3 (Name Numerology)
    p3 = kwargs.get("phase3_result")
    if p3:
        findings.append({
            "engine": "name_numerology",
            "label": "Name Vibrational Analysis (Phase 3)",
            "verdict": "YES",
            "statement": f"Name '{p3.get('name')}' vibrates to Compound {p3.get('compound_sum')} (Root {p3.get('single_root')}).",
            "confidence": 0.82,
            "actions": ["MAINTAIN_CURRENT_SPELLING"],
            "remedies_allowed": ["ROUTINE"]
        })

    # 4. Parse Phase 4 (Bhrigu Nandi Nadi)
    p4 = kwargs.get("phase4_result")
    if p4:
        combos = p4.get("relevant_bnn_combinations", [])
        has_block = any("delay" in str(c).lower() or "obstacle" in str(c).lower() or "saturn" in str(c).lower() for c in combos)
        findings.append({
            "engine": "bnn",
            "label": "Bhrigu Nandi Nadi (Phase 4)",
            "verdict": "DELAY" if has_block else "YES",
            "statement": f"BNN trinal connections reveal {len(combos)} active Sambandhas. {'Discipline and patience advised' if has_block else 'Strong career momentum detected'}.",
            "confidence": 0.89,
            "actions": ["PREPARE_FOUNDATION", "AVOID_IMPULSIVE_LEAPS"],
            "remedies_allowed": ["DISCIPLINE", "SEVA"]
        })

    # 5. Parse Phase 5 (Lal Kitab)
    p5 = kwargs.get("phase5_result")
    if p5:
        rems = p5.get("lal_kitab_remedies", [])
        findings.append({
            "engine": "lal_kitab",
            "label": "Lal Kitab Environmental Blueprint (Phase 5)",
            "verdict": "CONDITIONAL_YES",
            "statement": f"Lal Kitab identifies {len(rems)} environmental alignments to pacify sleeping or afflicted houses.",
            "confidence": 0.80,
            "actions": ["CLEAR_CLUTTER", "PRACTICE_DAAN"],
            "remedies_allowed": ["DAAN", "SEVA"]
        })

    # 6. Parse Phase 7 (KP Astrology)
    p7 = kwargs.get("phase7_result")
    if p7:
        sub_lord = p7.get("kp_sub_lord", "Venus")
        findings.append({
            "engine": "kp_astrology",
            "label": "KP Sub-Lord Stellar Timing (Phase 7)",
            "verdict": "YES",
            "statement": f"KP Sub Lord ({sub_lord}) positively bridges primary house significations.",
            "confidence": 0.92,
            "timing": {"earliest": "Next 30 days", "favorable_window": "Active Quarter"},
            "actions": ["EXECUTE_DECISION", "FINALIZE_AGREEMENTS"],
            "remedies_allowed": ["ROUTINE"]
        })

    # Detect conflicts
    conflicts = detect_conflicts(findings)

    # Priority Resolution
    priority_order = PRIORITY_MATRIX.get(topic, PRIORITY_MATRIX["general"])
    sorted_findings = sorted(
        findings,
        key=lambda x: (
            priority_order.index(x["engine"]) if x["engine"] in priority_order else 99,
            -x.get("confidence", 0)
        )
    )

    primary = sorted_findings[0] if sorted_findings else {"verdict": "CONDITIONAL_YES", "engine": "general"}
    secondary = sorted_findings[1] if len(sorted_findings) > 1 else None

    # Determine final consensus verdict
    if not secondary or primary["verdict"] == secondary["verdict"]:
        final_verdict = primary["verdict"]
        consensus_status = "STRONG_CONSENSUS"
        diff_explanation = "All prioritized calculation layers agree in direction and timing."
    elif primary["verdict"] in ["DELAY", "AVOID"] and secondary["verdict"] in ["YES", "STRONG_YES"]:
        final_verdict = "WAIT_OR_CONDITIONAL"
        consensus_status = "PARTIAL_CONFLICT"
        diff_explanation = (
            f"Your broader potential ({secondary['label']}) indicates positive growth, but the immediate "
            f"timing gatekeeper ({primary['label']}) advises preparation before final execution."
        )
    elif primary["verdict"] in ["YES", "STRONG_YES"] and secondary["verdict"] in ["DELAY", "AVOID"]:
        final_verdict = "CONDITIONAL_YES"
        consensus_status = "PARTIAL_CONFLICT"
        diff_explanation = (
            f"The primary timing window ({primary['label']}) is open and favorable, but an underlying karmic block "
            f"({secondary['label']}) must be addressed simultaneously."
        )
    else:
        final_verdict = primary["verdict"]
        consensus_status = "PRIMARY_DOMINANT"
        diff_explanation = f"Decision guided primarily by high-confidence {primary['label']} principles."

    # Map verdict to human-friendly title
    verdict_titles = {
        "STRONG_YES": "Strong Yes — Conditions Strongly Support Moving Ahead",
        "YES": "Yes — Proceed with Confidence and Preparation",
        "CONDITIONAL_YES": "Conditional Yes — Proceed, But Complete Your Foundation First",
        "WAIT_OR_CONDITIONAL": "Wait & Prepare — Timing Advises Patience and Groundwork",
        "DELAY": "Delay — The Direction is Right, but the Window Needs Patience",
        "AVOID": "Avoid for Now — High Friction Detected Across Multiple Systems"
    }

    # Resolve Safe Remedies
    chart_facts = kwargs.get("chart", {})
    remedy_pack = resolve_remedies(findings, chart_facts)

    # Resolve Spatiotemporal Astronomical Coordinates
    geo = kwargs.get("geo_context") or {
        "birth_time": "12:00",
        "place_name": "Delhi, India",
        "latitude": 28.6139,
        "longitude": 77.2090,
        "timezone": "Asia/Kolkata"
    }
    lat_card = "N" if geo["latitude"] >= 0 else "S"
    lon_card = "E" if geo["longitude"] >= 0 else "W"
    coord_display = f"{abs(geo['latitude']):.4f}° {lat_card}, {abs(geo['longitude']):.4f}° {lon_card}"

    # Build Charm AI Structured User Explanation (Melooha 9-Section Framework)
    charm_ai_response = {
        "spatiotemporal_anchor": {
            "birth_time": geo["birth_time"],
            "place_name": geo["place_name"],
            "latitude": geo["latitude"],
            "longitude": geo["longitude"],
            "timezone": geo["timezone"],
            "coordinates_formatted": coord_display,
            "astronomical_calibration": "Topocentric Horizon Lock (High-Precision Ephemeris Plane)"
        },
        "section_1_direct_answer": verdict_titles.get(final_verdict, final_verdict),
        "section_2_what_the_systems_say": [
            f"• Spatiotemporal Horizon: Topocentric birth locked at {geo['birth_time']} in {geo['place_name']} ({coord_display}, {geo['timezone']})."
        ] + [
            f"• {f['label']}: {f['statement']} (Verdict: {f['verdict']})"
            for f in findings
        ],
        "section_3_why_they_differ": diff_explanation,
        "section_4_what_this_means_for_you": (
            "Your long-term trajectory is stable and supported. However, rushing without completing due diligence "
            "can trigger unnecessary stress. Treat this phase as an active launchpad rather than an impulsive sprint."
        ),
        "section_5_what_to_do_now": [
            "1. Consolidate your core skills, documents, or partnership terms.",
            "2. Align your daily schedule to match high-productivity morning hours.",
            "3. Take deliberate, measured steps rather than gambling on sudden shortcuts."
        ],
        "section_6_what_to_avoid": [
            "1. Avoid impulsive resignations, sudden contract signings, or emotional confrontations.",
            "2. Do not purchase unverified or expensive gemstones under fear-based marketing.",
            "3. Avoid ignoring subtle red flags in communications."
        ],
        "section_7_safe_remedies": remedy_pack["recommended_remedies"],
        "section_8_confidence_and_consensus": {
            "consensus_level": consensus_status,
            "primary_authority_engine": primary["label"],
            "calculated_confidence_pct": round(primary["confidence"] * 100, 1),
            "astronomical_grounding": f"Precision-anchored to topocentric coordinates {coord_display} ({geo['place_name']}) at {geo['birth_time']}."
        },
        "section_9_anviel_your_next_charm": {
            "tagline": "Anviel Every Charm",
            "next_review_window": (datetime.now() + timedelta(days=30)).strftime("%d %B %Y"),
            "recommended_focus": "Re-check this question when your Antardasha transits into the next lunar cycle."
        }
    }

    # Context packet for continuous conversational LLM interaction (Melooha Vaani style)
    charm_ai_llm_payload = {
        "topic": topic,
        "final_verdict": final_verdict,
        "consensus_status": consensus_status,
        "primary_engine": primary["engine"],
        "spatiotemporal_anchor": geo,
        "conflicts": conflicts,
        "facts_summary": [f"{f['label']}: {f['statement']}" for f in findings],
        "remedy_safety": remedy_pack,
        "precomputed_explanation": charm_ai_response
    }

    return {
        "engine": "Charm AI Synthesis & Correlation Engine (Phase 6)",
        "topic": topic,
        "final_verdict": final_verdict,
        "consensus_status": consensus_status,
        "primary_engine": primary["label"],
        "spatiotemporal_anchor": geo,
        "conflicts_detected": conflicts,
        "charm_ai_response": charm_ai_response,
        "charm_ai_context_packet": charm_ai_llm_payload,
        "charm_ai_system_prompt": CHARM_AI_SYSTEM_PROMPT,
        "honesty_flag": "All calculations synthesized without suppressing cross-system disagreements."
    }
