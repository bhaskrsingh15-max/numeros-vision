from typing import Dict, Any, List
from app.engine.rag_retriever import rag_engine

# Standard Lo Shu Grid positions
LO_SHU_GRID_TEMPLATE = [
    [4, 9, 2],
    [3, 5, 7],
    [8, 1, 6]
]

PLANES = {
    "Mental Plane (4-9-2)": [4, 9, 2],
    "Emotional Plane (3-5-7)": [3, 5, 7],
    "Practical Plane (8-1-6)": [8, 1, 6],
    "Thought Plane (4-3-8)": [4, 3, 8],
    "Will Plane (9-5-1)": [9, 5, 1],
    "Action Plane (2-7-6)": [2, 7, 6],
    "Success Plane (4-5-6)": [4, 5, 6],
    "Loss/Disappointment Plane (2-5-8)": [2, 5, 8]
}

def analyze_lo_shu_grid(day: int, month: int, year: int) -> Dict[str, Any]:
    dob_str = f"{day:02d}{month:02d}{year}"
    digits = [int(d) for d in dob_str if d != '0']
    
    # Grid counts for numbers 1..9
    digit_counts = {num: digits.count(num) for num in range(1, 10)}
    
    # Check completed planes
    completed_planes = []
    incomplete_planes = []
    for plane_name, required_digits in PLANES.items():
        if all(digit_counts[d] > 0 for d in required_digits):
            completed_planes.append(plane_name)
        else:
            incomplete_planes.append(plane_name)

    missing_numbers = [num for num, count in digit_counts.items() if count == 0]
    present_numbers = [num for num, count in digit_counts.items() if count > 0]

    # Grounded RAG search for remedies on missing numbers
    remedy_passages = []
    if missing_numbers:
        missing_query = f"Missing numbers {' '.join(str(n) for n in missing_numbers)} remedies Lo Shu grid"
        remedy_passages = rag_engine.query(missing_query, top_k=3)

    return {
        "digit_counts": digit_counts,
        "grid_matrix": [
            [digit_counts[4], digit_counts[9], digit_counts[2]],
            [digit_counts[3], digit_counts[5], digit_counts[7]],
            [digit_counts[8], digit_counts[1], digit_counts[6]]
        ],
        "present_numbers": present_numbers,
        "missing_numbers": missing_numbers,
        "completed_planes": completed_planes,
        "incomplete_planes": incomplete_planes,
        "numeros_vision_remedies": [
            {
                "source": p["source"],
                "location": p["location"],
                "content": p["content"]
            } for p in remedy_passages
        ]
    }



def generate_loshu_grid_markdown(day: int, month: int, year: int) -> str:
    """
    Renders an authoritative, beautifully formatted ASCII Lo Shu Grid birth chart
    with elemental frequencies, missing karmic voids, and completed planes.
    """
    grid_data = analyze_lo_shu_grid(day, month, year)
    counts = grid_data["digit_counts"]
    
    def cell(num: int, elem: str) -> str:
        cnt = counts.get(num, 0)
        disp = str(num) * cnt if cnt > 0 else "GAP"
        return f"{num} ({elem}): {disp}"

    c4 = cell(4, "Wood")
    c9 = cell(9, "Fire")
    c2 = cell(2, "Earth")
    c3 = cell(3, "Wood")
    c5 = cell(5, "Earth")
    c7 = cell(7, "Metal")
    c8 = cell(8, "Earth")
    c1 = cell(1, "Water")
    c6 = cell(6, "Metal")

    present_str = ", ".join(str(n) for n in grid_data["present_numbers"]) or "None"
    missing_str = ", ".join(str(n) for n in grid_data["missing_numbers"]) if grid_data["missing_numbers"] else "None (Complete Matrix)"
    completed_str = ", ".join(grid_data["completed_planes"]) if grid_data["completed_planes"] else "None (Requires remedial grounding)"
    
    gap_descriptions = {
        1: "Missing 1 (Water · Career & Initiative): Difficulty asserting individuality; hesitation in taking decisive leadership leaps.",
        2: "Missing 2 (Earth · Intuition & Partnership): Emotional impatience; relationship friction; feeling ungrounded in team dynamics.",
        3: "Missing 3 (Wood · Knowledge & Expression): Creative stagnation; public expression hesitation; under-leveraging personal expertise.",
        4: "Missing 4 (Wood · Rahu Vault & Discipline): Structural wealth leak; high revenue struggles to convert into permanent physical assets.",
        5: "Missing 5 (Earth · Cosmic Center / Brahmasthan): Severe instability in focus; career restlessness; emotional oscillation during stress.",
        6: "Missing 6 (Metal · Venus Luxury Vibration): Delayed comfort manifestation; working hard but experiencing friction in family harmony.",
        7: "Missing 7 (Metal · Ketu Wisdom & Research): Repeating old mistakes; feeling spiritually disconnected; lack of deep analytical anchoring.",
        8: "Missing 8 (Earth · Saturn Discipline & Perseverance): Impatience with long-term execution; episodic financial disruptions.",
        9: "Missing 9 (Fire · Mars Energy & Vitality): Low physical momentum; reluctance to stand in the spotlight; courage and drive void."
    }

    gaps_md = []
    for m in grid_data["missing_numbers"]:
        if m in gap_descriptions:
            gaps_md.append(f"  • **{gap_descriptions[m]}**")

    gaps_section = "\n".join(gaps_md) if gaps_md else "  • All 9 single-digit numerical frequencies grounded in natal birth matrix."

    planes_md = []
    if 4 in grid_data["missing_numbers"] or 5 in grid_data["missing_numbers"] or 6 in grid_data["missing_numbers"]:
        planes_md.append("  • **Golden Prosperity Plane (4-5-6) Incomplete:** Revenue enters through Driver/Conductor but leaks before compounding.")
    if 2 in grid_data["missing_numbers"] or 5 in grid_data["missing_numbers"] or 8 in grid_data["missing_numbers"]:
        planes_md.append("  • **Silver Real Estate Plane (2-5-8) Void:** Periodic delays in property acquisitions and emotional grounding.")
    if 9 in grid_data["missing_numbers"] or 5 in grid_data["missing_numbers"] or 1 in grid_data["missing_numbers"]:
        planes_md.append("  • **Will & Persistence Plane (9-5-1) Disrupted:** Difficulty finishing ambitious multi-year projects.")

    planes_section = ("\n" + "\n".join(planes_md)) if planes_md else ""

    markdown = (
        f"### 🔲 Natal Lo Shu Grid Birth Chart ({day:02d}-{month:02d}-{year})\n\n"
        f"```\n"
        f"┌──────────────────────┬──────────────────────┬──────────────────────┐\n"
        f"│ {c4:<20} │ {c9:<20} │ {c2:<20} │\n"
        f"├──────────────────────┼──────────────────────┼──────────────────────┤\n"
        f"│ {c3:<20} │ {c5:<20} │ {c7:<20} │\n"
        f"├──────────────────────┼──────────────────────┼──────────────────────┤\n"
        f"│ {c8:<20} │ {c1:<20} │ {c6:<20} │\n"
        f"└──────────────────────┴──────────────────────┴──────────────────────┘\n"
        f"```\n\n"
        f"**✦ Natal Birth Chart Distribution:**\n"
        f"• **Present Elemental Frequencies:** [ {present_str} ]\n"
        f"• **Karmic Missing Digits (Gaps):** [ {missing_str} ]\n"
        f"• **Completed Elemental Planes:** {completed_str}\n\n"
        f"**✦ Karmic Gap & Elemental Diagnosis:**\n"
        f"{gaps_section}"
        f"{planes_section}\n"
    )
    return markdown

if __name__ == "__main__":
    res = analyze_lo_shu_grid(15, 8, 1995)
    print("Lo Shu Grid Analysis:")
    print("Grid Counts:", res["digit_counts"])
    print("Completed Planes:", res["completed_planes"])
    print("Missing Numbers:", res["missing_numbers"])
    print("Remedies retrieved:", len(res["numeros_vision_remedies"]))
