/**
 * Numeros Vision — Unified Cookie & Data Collection Consent Manager
 * Compliant with:
 * - India: Digital Personal Data Protection Act, 2023 (DPDP Act 2023, Sec 5, 6, 8, 9, 11-14)
 * - EU & UK: General Data Protection Regulation (GDPR / UK GDPR, Art 6, 7, ePrivacy Directive)
 * - US / California: California Consumer Privacy Act & Rights Act (CCPA / CPRA)
 * 
 * Aesthetic: Venus Pearl (#FFFDF7) & Jupiter Gold (#C9A227, #8B6914) Luxury Design
 * Zero pure black (#000000) allowed.
 */

(function () {
  'use strict';

  const CONSENT_STORAGE_KEY = 'nv_cookie_consent_v4';
  const CONSENT_LEGACY_KEY = 'nv_cookie_consent';
  const IDENTITY_STORAGE_KEY = 'nv_client_identity_id';
  const POLICY_VERSION = '2026.1.DPDP_GDPR';

  // 1. Helper: Generate or retrieve persistent 1P client identity
  function getOrCreateIdentityId() {
    let id = localStorage.getItem(IDENTITY_STORAGE_KEY);
    if (!id) {
      id = 'nv_id_' + 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
      try {
        localStorage.setItem(IDENTITY_STORAGE_KEY, id);
      } catch (e) {}
    }
    return id;
  }

  // 2. Helper: Sync consent record asynchronously to Numeros Vision backend ledger
  function syncConsentToBackend(level, preferences) {
    const identityId = getOrCreateIdentityId();
    const payload = {
      identity_id: identityId,
      purpose: level === 'all' ? 'ANALYTICS' : 'ESSENTIAL_SERVICE',
      status: level === 'dismissed' ? 'DISMISSED' : 'GRANTED',
      policy_version: POLICY_VERSION,
      jurisdiction: 'GLOBAL_DPDP_GDPR'
    };

    // Asynchronous non-blocking fetch to privacy API
    try {
      if (window.fetch) {
        fetch('/api/v1/privacy/consent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).catch(function (err) {
          // Graceful silent fallback for offline / mock dev mode
          console.debug('[Consent Manager] Backend ledger sync deferred:', err.message);
        });
      }
    } catch (e) {}
  }

  // 3. Inject CSS styles for the Consent Banner & Modal if not present
  function ensureConsentStyles() {
    if (document.getElementById('nv-consent-styles')) return;

    const style = document.createElement('style');
    style.id = 'nv-consent-styles';
    style.textContent = `
      .nv-consent-banner {
        position: fixed;
        bottom: 24px;
        left: 24px;
        max-width: 500px;
        width: calc(100% - 48px);
        background: #FFFDF7;
        border: 1.5px solid rgba(201, 162, 39, 0.45);
        border-radius: 18px;
        padding: 20px 24px;
        box-shadow: 0 14px 40px rgba(180, 155, 110, 0.22), 0 4px 14px rgba(30, 24, 16, 0.08);
        z-index: 99999;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: #523E28;
        display: none;
        opacity: 0;
        transform: translateY(16px);
        transition: opacity 0.35s ease, transform 0.35s ease;
      }
      .nv-consent-banner.visible {
        display: block !important;
        opacity: 1 !important;
        transform: translateY(0) !important;
      }
      .nv-consent-inner {
        display: flex;
        align-items: flex-start;
        gap: 14px;
      }
      .nv-consent-icon {
        font-size: 1.7rem;
        line-height: 1;
        flex-shrink: 0;
      }
      .nv-consent-content {
        flex: 1;
      }
      .nv-consent-title {
        margin: 0 0 6px 0;
        font-family: 'Cinzel', 'Cormorant Garamond', Georgia, serif;
        font-size: 1.15rem;
        font-weight: 700;
        color: #8B6914;
        letter-spacing: 0.03em;
      }
      .nv-consent-text {
        margin: 0 0 14px 0;
        font-size: 0.83rem;
        color: #523E28;
        line-height: 1.6;
      }
      .nv-consent-text a {
        color: #8B6914;
        font-weight: 600;
        text-decoration: underline;
        text-underline-offset: 2px;
      }
      .nv-consent-text a:hover {
        color: #C9A227;
      }
      .nv-consent-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
      }
      .nv-consent-btn-all {
        background: linear-gradient(135deg, #C9A227 0%, #8B6914 100%);
        color: #FFFFFF !important;
        border: none;
        border-radius: 20px;
        padding: 8px 18px;
        font-size: 0.81rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(201, 162, 39, 0.28);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
      }
      .nv-consent-btn-all:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(201, 162, 39, 0.38);
      }
      .nv-consent-btn-essential {
        background: #FAF6EE;
        color: #523E28;
        border: 1px solid rgba(201, 162, 39, 0.45);
        border-radius: 20px;
        padding: 8px 14px;
        font-size: 0.81rem;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s ease;
      }
      .nv-consent-btn-essential:hover {
        background: #F2ECE0;
      }
      .nv-consent-link-pref {
        font-size: 0.76rem;
        color: #7A654D;
        text-decoration: underline;
        cursor: pointer;
        margin-left: 4px;
        background: transparent;
        border: none;
        padding: 0;
      }
      .nv-consent-link-pref:hover {
        color: #8B6914;
      }
      .nv-consent-close {
        position: absolute;
        top: 12px;
        right: 14px;
        background: transparent;
        border: none;
        color: #7A654D;
        font-size: 1.3rem;
        line-height: 1;
        cursor: pointer;
        padding: 4px;
      }
      .nv-consent-close:hover {
        color: #8B6914;
      }
      @media (max-width: 600px) {
        .nv-consent-banner {
          left: 12px;
          bottom: 12px;
          width: calc(100% - 24px);
          padding: 16px 18px;
        }
      }
    `;
    document.head.appendChild(style);
  }

  // 4. Create or Ensure the DOM elements for the Cookie Consent Banner exist
  function ensureConsentBanner() {
    let banner = document.getElementById('nv-cookie-banner');
    if (!banner) {
      banner = document.createElement('aside');
      banner.id = 'nv-cookie-banner';
      banner.className = 'nv-consent-banner';
      banner.setAttribute('role', 'dialog');
      banner.setAttribute('aria-live', 'polite');
      banner.setAttribute('aria-label', 'Cookie and Privacy Consent Preferences');
      banner.innerHTML = `
        <button class="nv-consent-close" onclick="window.nvConsent.accept('dismissed')" aria-label="Close cookie notice" title="Dismiss cookie notice">&times;</button>
        <div class="nv-consent-inner">
          <div class="nv-consent-icon" aria-hidden="true">🛡️</div>
          <div class="nv-consent-content">
            <h4 class="nv-consent-title">Cookie &amp; Privacy Preferences</h4>
            <p class="nv-consent-text">
              We process essential mathematical session coordinates and anonymous telemetry under the <strong>DPDP Act 2023 (India)</strong> and <strong>GDPR (EU/UK)</strong>. We strictly enforce zero third-party data broker sharing and zero cross-site advertising pixels.
              <a href="/cookie-policy/">Read Cookie Policy</a> • <a href="/privacy-policy/">Privacy Policy</a>.
            </p>
            <div class="nv-consent-actions">
              <button class="nv-consent-btn-all" onclick="window.nvConsent.accept('all')">Accept All ✦</button>
              <button class="nv-consent-btn-essential" onclick="window.nvConsent.accept('essential')">Essential Only</button>
              <button class="nv-consent-link-pref" onclick="window.location.href='/privacy-policy/#privacy-vault'">Preferences Vault</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(banner);
    }
    return banner;
  }

  // 5. Consent Controller API
  const nvConsent = {
    init: function () {
      ensureConsentStyles();
      const existing = localStorage.getItem(CONSENT_STORAGE_KEY);
      if (!existing) {
        const banner = ensureConsentBanner();
        setTimeout(function () {
          banner.style.display = 'block';
          banner.classList.add('visible');
        }, 350);
      }
    },

    accept: function (level) {
      try {
        localStorage.setItem(CONSENT_STORAGE_KEY, level);
        localStorage.setItem(CONSENT_LEGACY_KEY, level);
        
        // Sync to backend ledger
        syncConsentToBackend(level);

        // Hide banner
        const banner = document.getElementById('nv-cookie-banner');
        if (banner) {
          banner.classList.remove('visible');
          setTimeout(function () {
            banner.style.display = 'none';
          }, 350);
        }

        // Notify marketing analytics script if present
        if (window.trackMarketingEvent) {
          window.trackMarketingEvent('ConsentUpdated', { consent_level: level });
        }

        // Notify other components (such as PWA manager) that consent has been resolved
        window.dispatchEvent(new CustomEvent('nv_consent_resolved', { detail: { level: level } }));
      } catch (e) {
        console.warn('[Consent Manager] Local storage write error:', e);
      }
    },

    reopen: function (e) {
      if (e && e.preventDefault) e.preventDefault();
      ensureConsentStyles();
      const banner = ensureConsentBanner();
      banner.style.display = 'block';
      setTimeout(function () {
        banner.classList.add('visible');
      }, 50);
    },

    getStatus: function () {
      const val = localStorage.getItem(CONSENT_STORAGE_KEY) || localStorage.getItem(CONSENT_LEGACY_KEY);
      return {
        level: val || 'unprompted',
        hasConsented: Boolean(val),
        isAllGranted: val === 'all',
        isEssentialOnly: val === 'essential'
      };
    }
  };

  // Expose globally
  window.nvConsent = nvConsent;
  window.initCookieConsent = nvConsent.init;
  window.acceptCookieConsent = nvConsent.accept;
  window.reopenCookieConsent = nvConsent.reopen;

  // Auto-run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', nvConsent.init);
  } else {
    nvConsent.init();
  }
})();
