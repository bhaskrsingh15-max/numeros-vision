/**
 * NUMEROS VISION — UNIFIED MARKETING FUNNEL & CONVERSION FRAMEWORK (v1.5.0)
 * Brand Tagline: ANVIEL EVERY CHARM
 * 
 * Governs the 3-Step Transition after any free calculation:
 *   Step 1: Your Result (Full, useful, un-degraded free calculation output - preserved)
 *   Step 2: The Curiosity Bridge ("Want to explore the next layer?")
 *   Step 3: The Standard Upgrade Panel (Deliverables, approved price in Gold, primary CTA)
 * 
 * Enforces:
 *   - Strictly ZERO raw black #000000
 *   - All prices in theme gold (#8B6914)
 *   - Correct brand spelling: "ANVIEL EVERY CHARM"
 *   - Marketing opt-out precedence
 *   - Privacy-minimised telemetry
 */

(function (window, document) {
  'use strict';

  // ── Product Catalogue Definitions (Synced with Server-Side funnel_service) ──
  const CATALOG = {
    birth_number: {
      id: 'birth_number',
      name: 'Birth Number Analysis',
      curiosity_hook: 'Want to Explore Your Number Further?',
      value_bridge: 'Your free calculation provides your foundational Driver (Mulank) frequency. Explore the complete dossier to understand planetary harmonics, career resonance, and personal year cycles.',
      primary_cta: 'Explore My Birth Number Report →',
      secondary_cta: 'Compare Personal Reports',
      tertiary_link: 'Preview a Sample Report',
      plan_id: 'report_essential',
      plan_name: 'Essential Cosmic Blueprint',
      price_inr: 199,
      original_price_inr: 399,
      root: 1,
      deliverables: [
        '12-15 Page Executive PDF Dossier',
        'Mulank (Driver) & Bhagyank (Conductor) Blueprint',
        'Lo Shu 3x3 Grid & Missing Numbers Audit',
        '1-Year Personal Timing Snapshot',
        'Primary Gemstone & Color Harmony Guide'
      ]
    },
    life_path: {
      id: 'life_path',
      name: 'Life Path Calculator',
      curiosity_hook: 'Explore the Wider Life Path Picture',
      value_bridge: 'Pure calculation frequency reduces your birth epoch to your core Life Path. Explore the next layer to unlock your 5-Year Vimshottari Dasha timeline and cross-verified career transit windows.',
      primary_cta: 'Get My Full Life Path Report →',
      secondary_cta: 'Compare All Plans',
      tertiary_link: 'Preview Sample Dossier',
      plan_id: 'report_master',
      plan_name: 'Master Dual-System Synthesis Dossier',
      price_inr: 510,
      original_price_inr: 999,
      root: 6,
      deliverables: [
        '35-40 Page Master Synthesis Dossier',
        'Full Name vs Calling Name Chaldean Audit',
        'BNN 1-5-9 Trines & 2-12 Wealth Vector Analysis',
        '5-Year 5-Tier Vimshottari Dasha Timeline',
        'Historical Milestone Accuracy Calibration',
        '7-Layer Safe Remedies (Mantra, Daan, Crystal, Lifestyle)'
      ]
    },
    name_numerology: {
      id: 'name_numerology',
      name: 'Name Numerology',
      curiosity_hook: 'Review the Additional Number Breakdown',
      value_bridge: 'Your free result shows your single-digit expression number. The complete analysis evaluates full vs calling name harmony, compound karmic debt, and spelling balancing.',
      primary_cta: 'Explore My Full Name Analysis →',
      secondary_cta: 'Compare Name Options',
      tertiary_link: 'How Name Balancing Works',
      plan_id: 'report_essential',
      plan_name: 'Essential Cosmic Blueprint',
      price_inr: 199,
      original_price_inr: 399,
      root: 1,
      deliverables: [
        'Full Name Vibration vs Driver-Conductor Compatibility',
        'Compound Number karmic debt assessment (13, 14, 16, 19, 28)',
        '3 Harmonized spelling calibration proposals',
        'Executive PDF deliverable with official brand seal'
      ]
    },
    chaldean_name: {
      id: 'chaldean_name',
      name: 'Chaldean Name Numerology',
      curiosity_hook: 'Discover the Ancient Sound Frequencies',
      value_bridge: 'Chaldean numerology focuses on occult compound vibrations. Explore how your compound number influences unseen career momentum and financial retention.',
      primary_cta: 'See the Compound Number Breakdown →',
      secondary_cta: 'Compare Name Options',
      tertiary_link: 'View Chaldean Methodology',
      plan_id: 'report_master',
      plan_name: 'Master Dual-System Synthesis Dossier',
      price_inr: 510,
      original_price_inr: 999,
      root: 6,
      deliverables: [
        'Chaldean Sound Frequency Analysis across all syllables',
        'Compound number occult symbolism & planetary ruler',
        '5-Year timing matrix calibrated with your calling vibration',
        'Consecrated sound frequency activation guide'
      ]
    },
    lo_shu_grid: {
      id: 'lo_shu_grid',
      name: 'Lo Shu 3x3 Grid',
      curiosity_hook: 'Harmonize Incomplete Energy Planes',
      value_bridge: 'Your free grid identifies present and missing numbers. The master report maps incomplete planes (Golden Prosperity 4-5-6, Will 9-5-1) and prescribes bespoke planetary remedies.',
      primary_cta: 'Explore My Complete Grid Report →',
      secondary_cta: 'Preview the Detailed Grid Report',
      tertiary_link: 'Explore Plane Meanings',
      plan_id: 'report_master',
      plan_name: 'Master Dual-System Synthesis Dossier',
      price_inr: 510,
      original_price_inr: 999,
      root: 6,
      deliverables: [
        '8 Planes of Lo Shu comprehensive audit',
        'Golden Prosperity Plane (4-5-6) leakage remediation',
        'Central Brahmasthan Anchor Number 5 grounding protocol',
        'Consecrated crystal, metal, and directional placement blueprint'
      ]
    },
    mobile_numerology: {
      id: 'mobile_numerology',
      name: 'Mobile Number Numerology',
      curiosity_hook: 'Uncover Paired Digit Harmonics',
      value_bridge: 'Every mobile contact number emits repetitive frequencies. The full report audits all 9 adjacent pairs and reveals whether your SIM aligns with business prosperity.',
      primary_cta: 'Get the Detailed Pair Analysis →',
      secondary_cta: 'View My Report Options',
      tertiary_link: 'Privacy & Data Masking Policy',
      plan_id: 'report_master',
      plan_name: 'Master Dual-System Synthesis Dossier',
      price_inr: 510,
      original_price_inr: 999,
      root: 6,
      deliverables: [
        'Complete 9-pair frequency audit (anti-pairs like 2-8, 4-8, 1-8)',
        'Commercial & wealth calling vibration assessment',
        'Auspicious digit replacement recommendations',
        'Zero PII retention policy guaranteed'
      ]
    },
    personal_year: {
      id: 'personal_year',
      name: 'Personal Year & Transit Engine',
      curiosity_hook: 'Map Your 12-Month Tactical Windows',
      value_bridge: 'Knowing your Personal Year number is step one. The full forecast breaks down month-by-month high-probability decision dates for career changes, investments, and contracts.',
      primary_cta: 'Explore My Personal Year Report →',
      secondary_cta: 'Compare Timing Options',
      tertiary_link: 'Review Forecast Methodology',
      plan_id: 'report_essential',
      plan_name: 'Essential Cosmic Blueprint',
      price_inr: 199,
      original_price_inr: 399,
      root: 1,
      deliverables: [
        '12-Month personal timing calendar',
        'Gochar (planetary transit) favorable action windows',
        'Quarterly strategic review recommendations',
        'Auspicious Muhurat dates for major milestones'
      ]
    },
    compatibility: {
      id: 'compatibility',
      name: 'Numerology Compatibility',
      curiosity_hook: 'Deepen Relational Synergy',
      value_bridge: 'Our free tool assesses Driver-Conductor natural harmony. The full relationship dossier explores karmic bonds, 36-point Guna Milan cross-checks, and constructive communication remedies.',
      primary_cta: 'Explore the Full Compatibility Report →',
      secondary_cta: 'Preview Compatibility Report',
      tertiary_link: 'View Synastry Principles',
      plan_id: 'report_master',
      plan_name: 'Master Dual-System Synthesis Dossier',
      price_inr: 510,
      original_price_inr: 999,
      root: 6,
      deliverables: [
        'Dual-Chart complete cross-synastry matrix',
        'Elemental compatibility (Fire, Water, Earth, Air)',
        'Conflict de-escalation timing windows',
        'Combined home energy and sacred geometry alignment'
      ]
    },
    business_direction: {
      id: 'business_direction',
      name: 'Business Direction & Entity Matrix',
      curiosity_hook: 'Align Corporate Brand with Market Timing',
      value_bridge: 'A business entity holds its own vibrational signature. Our corporate dossier validates trade name vibrations, founder synastry, and incorporation Muhurat windows.',
      primary_cta: 'Explore My Business Alignment Report →',
      secondary_cta: 'Compare Business Options',
      tertiary_link: 'Corporate Confidentiality Terms',
      plan_id: 'advisory_business_name',
      plan_name: 'Commercial Entity & Brand Matrix',
      price_inr: 5999,
      original_price_inr: 14000,
      root: 5,
      deliverables: [
        'Corporate Legal Name & Trade Name vibration audit',
        'Founder & Co-Founder Synergy Compatibility Matrix',
        'Incorporation & Launch Muhurat (3 high-probability dates)',
        'Bank Account & Invoicing numerical vibration audit'
      ]
    },
    charm_ai: {
      id: 'charm_ai',
      name: 'Charm AI Oracle',
      curiosity_hook: 'Engage in Conversational Cosmic Counsel',
      value_bridge: 'Charm AI answers with zero-hallucination classical numerology and astrology synthesis. Unlock 15 detailed question predictions and customized safe remedies.',
      primary_cta: 'Explore a Deeper Reading →',
      secondary_cta: 'Compare Charm AI Plans',
      tertiary_link: 'Review Classical Sources',
      plan_id: 'ai_growth_15q',
      plan_name: 'Charm AI — Growth Pack (15 Questions + Remedies)',
      price_inr: 249,
      original_price_inr: 499,
      root: 6,
      deliverables: [
        '15 In-depth Question Predictions',
        'Customized 7-Layer Safe Remedies for each query',
        'Auspicious timing windows & lucky dates',
        'Zero hallucination guarantee bound to classical texts'
      ]
    }
  };

  // ── Telemetry & Opt-Out Helper ─────────────────────────────────────────────
  function trackEvent(eventName, productId, metadata) {
    try {
      if (localStorage.getItem('nv_marketing_opt_out') === 'true') return;
      const payload = {
        event: eventName,
        product_id: productId || 'unknown',
        stage: 'CONSIDERATION',
        metadata: metadata || {}
      };
      if (navigator.sendBeacon) {
        navigator.sendBeacon('/api/v1/payments/funnel/event', JSON.stringify(payload));
      } else {
        fetch('/api/v1/payments/funnel/event', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          keepalive: true
        }).catch(() => {});
      }
    } catch (e) {}
  }

  function isOptedOut() {
    return localStorage.getItem('nv_marketing_opt_out') === 'true';
  }

  function setOptOut(state) {
    if (state) {
      localStorage.setItem('nv_marketing_opt_out', 'true');
      trackEvent('marketing_opt_out', 'all');
    } else {
      localStorage.removeItem('nv_marketing_opt_out');
    }
  }

  // ── Render 3-Step Result-to-Offer Funnel Component ──────────────────────────
  /**
   * Renders the unified Curiosity Bridge and Standard Upgrade Panel.
   * @param {string|HTMLElement} container - The DOM element or ID to render inside.
   * @param {Object} options - Configuration options:
   *   @param {string} options.productId - e.g. 'life_path', 'birth_number', 'lo_shu_grid'
   *   @param {Object} [options.diagnosticSummary] - Short calculated stats to echo
   *   @param {string} [options.personName] - Seeker's name
   *   @param {string} [options.askCharmUrl] - Direct pre-filled link to Charm AI
   */
  function renderOfferBridge(container, options) {
    const el = typeof container === 'string' ? document.getElementById(container) : container;
    if (!el) return;

    if (isOptedOut()) {
      el.innerHTML = `
        <div style="background:var(--bg-card, #FFFDF7);border:1px dashed var(--border-gold, #C9A227);border-radius:12px;padding:14px 20px;text-align:center;margin-top:18px;">
          <p style="font-size:0.82rem;color:var(--text-muted, #7A654D);margin:0 0 6px 0;">
            ✦ Marketing prompts are paused. Your free calculation results are preserved.
          </p>
          <button type="button" id="btnResumeOffers" style="background:none;border:none;color:#8B6914;font-size:0.78rem;font-weight:600;cursor:pointer;text-decoration:underline;">
            Show personalized report options
          </button>
        </div>
      `;
      const resumeBtn = el.querySelector('#btnResumeOffers');
      if (resumeBtn) {
        resumeBtn.addEventListener('click', function() {
          setOptOut(false);
          renderOfferBridge(container, options);
        });
      }
      return;
    }

    const opts = options || {};
    const pid = opts.productId || 'life_path';
    const prod = CATALOG[pid] || CATALOG.life_path;
    const pName = opts.personName ? `${opts.personName}'s ` : 'Your ';
    const charmUrl = opts.askCharmUrl || `/charm-ai/?q=Tell+me+more+about+my+${encodeURIComponent(prod.name)}&auto=true`;

    const savings = prod.original_price_inr - prod.price_inr;
    const discountPercent = Math.round((savings / prod.original_price_inr) * 100);

    const deliverablesHtml = prod.deliverables.map(d => `
      <li style="display:flex;align-items:flex-start;gap:8px;font-size:0.84rem;color:var(--text-primary, #523E28);line-height:1.55;margin-bottom:6px;">
        <span style="color:#16835B;font-weight:700;flex-shrink:0;">✓</span>
        <span>${d}</span>
      </li>
    `).join('');

    const html = `
      <div class="nv-funnel-offer-bridge" style="margin-top:24px;border:1.5px solid var(--border-gold, #C9A227);border-radius:18px;background:var(--bg-card, #FFFDF7);box-shadow:0 10px 32px rgba(180,155,110,0.1);overflow:hidden;position:relative;">
        
        <!-- Step 2: The Curiosity Bridge -->
        <div style="background:linear-gradient(135deg, rgba(201,162,39,0.08) 0%, rgba(22,131,91,0.04) 100%);padding:22px 24px;border-bottom:1px solid rgba(201,162,39,0.25);text-align:center;">
          <div style="display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:50%;background:rgba(201,162,39,0.12);border:1.5px solid var(--gold, #C9A227);font-size:1.3rem;color:#8B6914;margin-bottom:8px;">
            🔒
          </div>
          <div style="font-family:'Cinzel', serif;font-size:0.70rem;letter-spacing:0.16em;text-transform:uppercase;color:#8B6914;font-weight:700;margin-bottom:4px;">
            NUMEROS VISION · ANVIEL EVERY CHARM
          </div>
          <h3 style="font-family:'Cormorant Garamond',serif;font-size:1.55rem;color:#523E28;margin:0 0 8px 0;font-weight:700;">
            Anviel Your ${prod.name.replace(' Analysis', '').replace(' Calculator', '')} Charm — Unlock ${prod.plan_name}
          </h3>
          <p style="font-size:0.88rem;color:#7A654D;line-height:1.6;max-width:620px;margin:0 auto;">
            ${prod.value_bridge}
          </p>
        </div>

        <!-- Step 3: The Standard Upgrade Panel -->
        <div style="padding:22px 24px;">
          <div style="display:grid;grid-template-columns:1fr;gap:18px;">
            <div>
              <div style="font-size:0.74rem;letter-spacing:0.08em;text-transform:uppercase;color:#8B6914;font-weight:700;margin-bottom:10px;">
                Verified Inclusions in ${prod.plan_name}:
              </div>
              <ul style="list-style:none;padding:0;margin:0 0 16px 0;">
                ${deliverablesHtml}
              </ul>
            </div>

            <!-- Price & Action Area -->
            <div style="background:#F7F3EA;border:1px solid rgba(201,162,39,0.25);border-radius:14px;padding:16px 20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;">
              <div>
                <div style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted, #7A654D);font-weight:600;margin-bottom:2px;">
                  Approved Single Investment
                </div>
                <div style="display:flex;align-items:baseline;gap:8px;">
                  <span style="font-size:1.6rem;font-family:'Cormorant Garamond',serif;font-weight:700;color:#8B6914;">
                    ₹${prod.price_inr.toLocaleString('en-IN')}
                  </span>
                  <span style="font-size:0.88rem;color:var(--text-muted, #7A654D);text-decoration:line-through;">
                    ₹${prod.original_price_inr.toLocaleString('en-IN')}
                  </span>
                  <span style="padding:2px 8px;border-radius:100px;background:#16835B;color:#FFFFFF;font-size:0.68rem;font-weight:700;">
                    ${discountPercent}% OFF
                  </span>
                </div>
                <div style="font-size:0.72rem;color:var(--text-muted, #7A654D);margin-top:2px;">
                  One-time purchase · Instant PDF download
                </div>
              </div>

              <!-- Primary CTA -->
              <div style="display:flex;flex-direction:column;gap:8px;min-width:240px;">
                <a href="/checkout/?plan=${prod.plan_id}&tool=${prod.id}" class="nv-funnel-btn-primary" data-product="${prod.id}" data-plan="${prod.plan_id}" style="display:inline-block;text-align:center;background:linear-gradient(135deg, #C9A227 0%, #8B6914 100%);color:#FFFFFF;padding:12px 22px;border-radius:100px;font-weight:700;font-size:0.86rem;text-decoration:none;box-shadow:0 4px 14px rgba(139,105,20,0.25);transition:all 0.2s ease;">
                  🔒 Anviel Your Charm · Unlock Report (₹${prod.price_inr.toLocaleString('en-IN')}) ✦
                </a>
              </div>
            </div>

            <!-- Secondary Actions & Reassurance Strip -->
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;padding-top:6px;border-top:1px solid rgba(201,162,39,0.15);">
              <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;">
                <a href="/pricing#plans" style="font-size:0.78rem;color:#8B6914;font-weight:600;text-decoration:underline;">
                  ${prod.secondary_cta}
                </a>
                <span style="font-size:0.75rem;color:var(--text-muted, #7A654D);">·</span>
                <a href="${charmUrl}" style="font-size:0.78rem;color:#16835B;font-weight:600;text-decoration:none;">
                  Ask Charm AI Free ✦
                </a>
                <span style="font-size:0.75rem;color:var(--text-muted, #7A654D);">·</span>
                <a href="/sample-report/" style="font-size:0.78rem;color:var(--text-muted, #7A654D);text-decoration:none;">
                  ${prod.tertiary_link}
                </a>
              </div>

              <div style="display:flex;align-items:center;gap:12px;">
                <span style="font-size:0.72rem;color:var(--text-muted, #7A654D);">
                  🔒 256-Bit Encrypted · Zero Dark Patterns
                </span>
                <button type="button" class="nv-funnel-opt-out" style="background:none;border:none;color:var(--text-muted, #7A654D);font-size:0.7rem;cursor:pointer;text-decoration:none;opacity:0.7;" title="Dismiss promotional offers">
                  Hide Offer ✕
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
    `;

    el.innerHTML = html;

    // Attach Event Listeners
    const primaryBtn = el.querySelector('.nv-funnel-btn-primary');
    if (primaryBtn) {
      primaryBtn.addEventListener('click', function () {
        trackEvent('checkout_started', prod.id, {
          plan_id: prod.plan_id,
          price_inr: prod.price_inr
        });
      });
    }

    const optOutBtn = el.querySelector('.nv-funnel-opt-out');
    if (optOutBtn) {
      optOutBtn.addEventListener('click', function () {
        setOptOut(true);
        renderOfferBridge(container, options);
      });
    }

    // Telemetry: Upgrade panel viewed
    trackEvent('upgrade_panel_viewed', prod.id, {
      plan_id: prod.plan_id,
      price_inr: prod.price_inr
    });
  }

  // Expose global namespace
  window.nvFunnel = {
    renderOfferBridge: renderOfferBridge,
    trackEvent: trackEvent,
    isOptedOut: isOptedOut,
    setOptOut: setOptOut,
    CATALOG: CATALOG
  };

})(window, document);
