"""
app/charm/intent/event_intent_service.py
=========================================
Intent Parsing & Event Definition Service for Charm AI.
Complies with Section 4 (Step 1, Step 2) and Section 6 of
the Gap-Analysis Rectification Specification.
"""

import re
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

EVENT_TAXONOMY = {
    "career": {
        "keywords": [
            "job", "career", "promotion", "business", "vocation", "profession",
            "boss", "interview", "startup", "office", "naukri", "vyapar",
            "senior", "appointment", "switch", "pivot", "role", "leadership",
            "position", "work", "firm", "company", "employment", "hire", "hiring",
            "promote", "promoted", "director", "raise", "increment", "appraisal"
        ],
        "event_types": [
            "new_job_or_senior_role",
            "promotion",
            "career_change",
            "business_venture",
            "executive_appointment"
        ]
    },
    "wealth": {
        "keywords": [
            "money", "wealth", "finance", "income", "salary", "investment",
            "shares", "stocks", "debt", "loan", "paisa", "dhan"
        ],
        "event_types": [
            "capital_gain", "debt_clearance", "financial_stability", "investment_window"
        ]
    },
    "marriage": {
        "keywords": [
            "marriage", "love", "relationship", "partner", "husband", "wife",
            "spouse", "shaadi", "vivah", "dating"
        ],
        "event_types": [
            "marriage_timing", "relationship_harmony", "partner_meeting"
        ]
    },
    "health": {
        "keywords": [
            "health", "vitality", "illness", "wellness", "energy", "sehat",
            "stress", "sleep", "recovery", "fatigue"
        ],
        "event_types": [
            "vitality_restoration", "stress_reduction", "circadian_harmony"
        ]
    },
    "property": {
        "keywords": [
            "property", "house", "home", "land", "flat", "vehicle", "car",
            "makan", "zameen", "ghar", "vastu"
        ],
        "event_types": [
            "property_purchase", "relocation", "home_consecration"
        ]
    },
    "general": {
        "keywords": ["life", "destiny", "timing", "cycle", "future", "numbers", "charm"],
        "event_types": ["annual_forecast", "destiny_milestone", "dasha_alignment"]
    }
}

class EventIntent(BaseModel):
    event_definition_id: str
    event_family: str = Field(..., description="career, wealth, marriage, health, property, general")
    event_type: str = Field(..., description="Specific event type (e.g. new_job_or_senior_role, promotion)")
    event_definition: str = Field(..., description="Human-readable event description")
    goal_or_problem: str
    requested_horizon: str = Field("unspecified_horizon", description="User's requested forecast window, separated from calculated timing")
    available_inputs: List[str] = Field(default_factory=list)
    missing_inputs: List[str] = Field(default_factory=list)
    required_rules: List[str] = Field(default_factory=list)
    blocked_calculations: List[str] = Field(default_factory=list)
    safe_interim_conclusions: List[str] = Field(default_factory=list)
    needs_clarification: bool = False
    clarification_question: Optional[str] = None
    provenance_notes: List[str] = Field(default_factory=list)

class EventIntentService:
    def parse_intent(self, question: str, profile_facts: Dict[str, Any]) -> EventIntent:
        clean_q = question.strip()
        ql = clean_q.lower()

        # 1. Parse Requested Forecast Horizon (explicitly separate from calculated timing)
        requested_horizon = "unspecified_horizon"
        if re.search(r'\b(6|six)\s*(month|months|mo)\b', ql) or "half year" in ql:
            requested_horizon = "6_months"
        elif re.search(r'\b(3|three)\s*(month|months|quarter)\b', ql):
            requested_horizon = "3_months"
        elif re.search(r'\b(1|one|12)\s*(year|years|months|yr)\b', ql) or "2026" in ql or "this year" in ql:
            requested_horizon = "12_months"
        elif re.search(r'\b(2|two|24)\s*(years|months|yrs)\b', ql):
            requested_horizon = "24_months"

        # 2. Identify Event Family
        matched_family = "general"
        highest_score = 0
        for family, data in EVENT_TAXONOMY.items():
            score = sum(1 for kw in data["keywords"] if re.search(r'\b' + re.escape(kw) + r'\b', ql))
            if score > highest_score:
                highest_score = score
                matched_family = family

        # 3. Disambiguate Specific Event Type & Career Goals
        if matched_family == "career":
            if any(k in ql for k in ["promotion", "promoted", "promote", "hike", "appraisal", "increment", "level up"]):
                matched_type = "promotion"
            elif any(k in ql for k in ["change career", "career switch", "switch career", "new profession", "different field", "switch fields"]):
                matched_type = "career_change"
            elif any(k in ql for k in ["senior", "leadership", "executive", "director", "head", "lead", "job", "role", "naukri", "interview"]):
                matched_type = "new_job_or_senior_role"
            elif any(k in ql for k in ["business", "startup", "venture", "freelance", "founder", "own firm", "company"]):
                matched_type = "business_venture"
            elif any(k in ql for k in ["change", "switch", "pivot"]):
                matched_type = "career_change"
            else:
                matched_type = "new_job_or_senior_role"
        else:
            event_types = EVENT_TAXONOMY[matched_family]["event_types"]
            matched_type = event_types[0]
            for et in event_types:
                words = et.split("_")
                if any(w in ql for w in words):
                    matched_type = et
                    break

        # 4. Input & Evidence Validation
        available = []
        missing = []
        blocked = []
        provenance = []

        if profile_facts.get("name"):
            available.append("user_name")
        
        has_day = bool(profile_facts.get("day"))
        has_month = bool(profile_facts.get("month"))
        has_year = bool(profile_facts.get("year"))

        if has_day and has_month and has_year:
            available.append("birth_date")
            provenance.append("User-supplied Date of Birth (pending practitioner verification)")
        else:
            missing.append("birth_date")
            blocked.append("Deterministic Numerology Dasha timing calculation")
            blocked.append("Acute Pratyantardasha window estimation")

        if profile_facts.get("loshu_grid") or profile_facts.get("digit_counts"):
            available.append("user_supplied_loshu")
            provenance.append("User-supplied Lo Shu numbers retained as static natal inventory (does not establish Dasha timing)")

        if profile_facts.get("tob"):
            available.append("time_of_birth")
        if profile_facts.get("pob") or profile_facts.get("city"):
            available.append("city_of_birth")

        # 5. Formulate Human-Readable Event Definition
        definition_map = {
            "new_job_or_senior_role": "Transition into a new job or senior institutional leadership appointment",
            "promotion": "Institutional promotion, band advancement, or executive authority expansion",
            "career_change": "Strategic career pivot into a new operational domain",
            "business_venture": "Commercial venture expansion and independent market agility",
            "capital_gain": "Financial milestone and capital accumulation",
            "debt_clearance": "Debt neutralization and financial recovery",
            "marriage_timing": "Auspicious marriage alliance and domestic union",
            "vitality_restoration": "Nervous system equilibrium and physical vitality",
            "property_purchase": "Real estate acquisition and fixed asset foundation",
            "annual_forecast": "Annual epicycle forecast and strategic roadmap"
        }
        event_definition = definition_map.get(matched_type, f"Event timing and planetary alignment for {matched_family}")
        event_id = f"EVT-{matched_family.upper()}-{matched_type.upper()}"

        # 6. Safe Interim Conclusions when data is partial
        interim = []
        if "birth_date" not in available:
            interim.append("Static natal frequency insights can be reviewed once birth date is confirmed.")
            interim.append("No specific job offer dates or appointment months can responsibly be predicted without verified birth date.")
        else:
            interim.append("Birth date confirmed; timing calculations ready for deterministic evaluation.")

        # 7. Single Concise Clarification Question
        needs_clarification = len(missing) > 0
        clarification_q = None
        if "birth_date" in missing:
            clarification_q = "To calculate your exact Numerology Dasha timing window, please provide your date of birth (Day, Month, Year)."

        required_rules = [
            "SRC-NV-001: Numerology Dasha 9-Year Epicycle Rules",
            "SRC-NV-003: Planetary Karaka Career Signification Rules"
        ]

        return EventIntent(
            event_definition_id=event_id,
            event_family=matched_family,
            event_type=matched_type,
            event_definition=event_definition,
            goal_or_problem=clean_q,
            requested_horizon=requested_horizon,
            available_inputs=available,
            missing_inputs=missing,
            required_rules=required_rules,
            blocked_calculations=blocked,
            safe_interim_conclusions=interim,
            needs_clarification=needs_clarification,
            clarification_question=clarification_q,
            provenance_notes=provenance
        )

event_intent_service = EventIntentService()
