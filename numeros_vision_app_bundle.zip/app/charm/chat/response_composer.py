"""
app/charm/chat/response_composer.py
====================================
End-to-End Response Composer & Orchestrator for Charm AI.
Complies with Section 4, 6, 7, and 9 of Gap-Analysis Rectification Specification:
- Enforces Numerology Dasha-first workflow strictly at the backend.
- Separates user's requested forecast horizon from calculated Dasha windows.
- Emits structured missing data breakdowns & abstains when required inputs/rules are missing.
- Implements the prioritized 7-Tier human-friendly response hierarchy.
- Provides full audit trace and immutable prediction snapshotting.
"""

from datetime import datetime
import hashlib
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from app.charm.intent.event_intent_service import event_intent_service, EventIntent
from app.charm.numerology.dasha_engine import numerology_dasha_engine, NumerologyDashaResult
from app.charm.charts.fact_provider import planetary_fact_provider
from app.charm.methods.kp_adapter import kp_adapter, MethodEvaluation
from app.charm.methods.vedic_adapter import vedic_adapter
from app.charm.methods.bnn_adapter import bnn_adapter
from app.charm.methods.pythagorean_adapter import pythagorean_adapter
from app.charm.methods.vedic_numerology_adapter import vedic_numerology_adapter
from app.charm.methods.lal_kitab_adapter import lal_kitab_adapter
from app.charm.consensus.engine import consensus_engine, ConsensusResult
from app.charm.remedies.remedy_service import remedy_service, RemedyItem
from app.charm.rag.source_governor import source_governor
from app.charm.outcomes.outcome_service import outcome_service, PredictionSnapshot
from app.charm.chat.humanized_consultant import generate_humanized_consultation

class HumanFriendlySummary(BaseModel):
    takeaway: str = Field(..., description="Tier 1: Concise career takeaway")
    timing_status: str = Field(..., description="Tier 2: Timing status and verification level")
    supported_by_report: str = Field(..., description="Tier 3: What the supplied report supports")
    unconcluded_aspects: str = Field(..., description="Tier 4: What cannot yet be concluded")
    missing_inputs_explanation: str = Field(..., description="Tier 5: Exact missing calculation or input")
    practical_actions: List[str] = Field(default_factory=list, description="Tier 6: Practical job-search actions")
    followup_question: str = Field(..., description="Tier 7: Optional neutral follow-up question")
    full_dialogue_text: Optional[str] = Field(None, description="Humanized conversational consultation dialogue")
    driver_title: Optional[str] = None
    driver_planet: Optional[str] = None
    conductor_title: Optional[str] = None

class CharmPredictionViewModel(BaseModel):
    prediction_id: str
    primary_method: str = "NUMEROLOGY_DASHA"
    verification_status: str
    event_assessment: str
    requested_horizon: str
    primary_windows: List[Dict[str, Any]]
    numerology_summary: str
    corroboration_summary: str
    provenance_record: Dict[str, Any]
    missing_requirements: Dict[str, Any]
    limitations: List[str]
    method_evidence: List[Dict[str, Any]]
    practical_steps: List[str]
    optional_remedies: List[Dict[str, Any]]
    human_friendly: Dict[str, Any]

class CharmChatResponse(BaseModel):
    conversation_id: str
    message_id: str
    status: str = Field("ANSWERED", description="ANSWERED, INSUFFICIENT_EVIDENCE, NOT_ELIGIBLE, NEEDS_CLARIFICATION, ERROR")
    assistant_message: Dict[str, Any]
    input_validation: Dict[str, Any]
    numerology_dasha_result: Dict[str, Any]
    career_event_assessment: Dict[str, Any]
    cross_verification: List[Dict[str, Any]]
    consensus_status: str
    evidence_citations: List[Dict[str, Any]]
    missing_requirements: Dict[str, Any]
    human_friendly_summary: Dict[str, Any]
    practical_next_steps: List[str]
    calculation_version: str = "2.0.0"
    audit_trace_id: str
    prediction: Optional[Dict[str, Any]] = None
    follow_up_question: Optional[str] = None
    safety_flags: List[str] = Field(default_factory=list)

class CharmChatOrchestrator:
    def process_chat_turn(
        self,
        message: str,
        user_name: str = "Seeker",
        day: Optional[int] = None,
        month: Optional[int] = None,
        year: Optional[int] = None,
        conversation_id: Optional[str] = None,
        user_id: str = "guest_user",
        tob: Optional[str] = None,
        pob: Optional[str] = None,
        loshu_grid: Optional[Dict[str, Any]] = None
    ) -> CharmChatResponse:
        trace_id = f"NV-TRC-{datetime.now().strftime('%Y%m%d')}-{hashlib.md5((message + str(day)).encode('utf-8')).hexdigest()[:8].upper()}"
        conv_id = conversation_id or f"CONV-{hashlib.sha256(message.encode('utf-8')).hexdigest()[:10]}"
        msg_id = f"MSG-{datetime.now().strftime('%Y%m%d%H%M%S')}-{hashlib.md5(message.encode('utf-8')).hexdigest()[:6]}"

        profile_facts = {
            "name": user_name,
            "day": day,
            "month": month,
            "year": year,
            "tob": tob,
            "pob": pob,
            "loshu_grid": loshu_grid
        }

        # Step 1: Intent & Horizon Classification
        intent: EventIntent = event_intent_service.parse_intent(message, profile_facts)

        # Step 2: Handle Missing Inputs / Abstention Gate
        is_birth_date_missing = "birth_date" in intent.missing_inputs
        if is_birth_date_missing:
            dasha_res: NumerologyDashaResult = numerology_dasha_engine.evaluate_dasha_hierarchy(
                day=0,
                month=0,
                year=0,
                event_definition_id=intent.event_definition_id
            )
            consensus_res = consensus_engine.derive_consensus(
                primary_numerology=dasha_res,
                evaluations=[],
                event_definition=intent.model_dump()
            )

            missing_reqs = {
                "available_inputs": intent.available_inputs,
                "missing_inputs": intent.missing_inputs,
                "why_required": "Date of birth (Day, Month, Year) is the mandatory mathematical foundation to calculate Driver, Conductor, and Numerology Dasha timing cycles.",
                "required_rules": intent.required_rules,
                "blocked_calculations": intent.blocked_calculations,
                "safe_interim_conclusions": intent.safe_interim_conclusions
            }

            human_friendly = HumanFriendlySummary(
                takeaway="Career timing analysis is currently abstained pending verified birth date inputs. User-supplied Lo Shu numbers represent static natal inventory, but cannot establish an active timing window without birth dates.",
                timing_status="Status: INSUFFICIENT_EVIDENCE · Timing Window: Uncalculated",
                supported_by_report="The supplied profile confirms your career interest; however, no date-derived epicycle can be computed yet.",
                unconcluded_aspects="No job offer dates, appointment months, or favorable horizons can responsibly be predicted.",
                missing_inputs_explanation="Missing exact Date of Birth (Day, Month, Year). Astrological cross-checks also remain on standby.",
                practical_actions=[
                    "Conduct a structured resume and portfolio audit highlighting quantifiable leadership outcomes.",
                    "Identify 3 target institutions or executive search leaders aligned with your domain expertise."
                ],
                followup_question="To calculate your active Numerology Dasha timing window, what is your date of birth (Day, Month, Year)?"
            )

            direct_text = (
                f"Namaste {user_name} 🙏\n\n"
                f"**1. Career Takeaway:** {human_friendly.takeaway}\n\n"
                f"**2. Timing Status:** {human_friendly.timing_status}\n\n"
                f"**3. What Can Be Concluded:** {human_friendly.supported_by_report}\n\n"
                f"**4. What Cannot Be Concluded:** {human_friendly.unconcluded_aspects}\n\n"
                f"**5. Missing Requirements:** {human_friendly.missing_inputs_explanation}\n\n"
                f"**6. Practical Next Steps:**\n• " + "\n• ".join(human_friendly.practical_actions) + f"\n\n"
                f"**7. Next Step:** {human_friendly.followup_question}"
            )

            pred_vm = CharmPredictionViewModel(
                prediction_id=f"PRED-ABSTAIN-{hashlib.md5(message.encode('utf-8')).hexdigest()[:8]}",
                primary_method="NUMEROLOGY_DASHA",
                verification_status="INSUFFICIENT_EVIDENCE",
                event_assessment="NEUTRAL",
                requested_horizon=intent.requested_horizon,
                primary_windows=[],
                numerology_summary="Calculation abstained: Date of birth missing.",
                corroboration_summary="Independent astrological systems on standby; no primary window to cross-verify.",
                provenance_record={
                    "dob": "missing",
                    "dob_provenance": "unverified",
                    "loshu_conflation_guard": "Lo Shu chart retained as static natal digit inventory; does NOT establish Dasha periods or timing windows."
                },
                missing_requirements=missing_reqs,
                limitations=[
                    "Numerology Dasha calculation is strictly deterministic and requires verified birth dates.",
                    "No dates or favorable months are hallucinated or fabricated."
                ],
                method_evidence=[],
                practical_steps=human_friendly.practical_actions,
                optional_remedies=[],
                human_friendly=human_friendly.model_dump()
            )

            return CharmChatResponse(
                conversation_id=conv_id,
                message_id=msg_id,
                status="INSUFFICIENT_EVIDENCE",
                assistant_message={"text": direct_text, "sections": []},
                input_validation={"available_inputs": intent.available_inputs, "missing_inputs": intent.missing_inputs},
                numerology_dasha_result={"status": "INSUFFICIENT_EVIDENCE", "primary_windows": []},
                career_event_assessment={"goal": intent.event_type, "requested_horizon": intent.requested_horizon, "assessment": "NEUTRAL"},
                cross_verification=[],
                consensus_status="INSUFFICIENT_EVIDENCE",
                evidence_citations=[],
                missing_requirements=missing_reqs,
                human_friendly_summary=human_friendly.model_dump(),
                practical_next_steps=human_friendly.practical_actions,
                calculation_version="2.0.0",
                audit_trace_id=trace_id,
                prediction=pred_vm.model_dump(),
                follow_up_question=human_friendly.followup_question,
                safety_flags=["CALCULATION_INPUT_MISSING"]
            )

        # Step 3: Deterministic Numerology Dasha Calculation
        dasha_res: NumerologyDashaResult = numerology_dasha_engine.evaluate_dasha_hierarchy(
            day=day or 1,
            month=month or 1,
            year=year or 1990,
            event_definition_id=intent.event_definition_id
        )

        # Step 4: Astronomical Ephemeris & Facts
        chart_facts = planetary_fact_provider.get_chart_facts(city=pob or "delhi")

        # Step 5: Independent Cross-Verification Adapters
        eval_profile = {
            "driver": dasha_res.driver,
            "conductor": dasha_res.conductor,
            "personal_year": dasha_res.personal_year,
            "day": day,
            "month": month,
            "year": year,
            "name": user_name
        }
        hypothesis_window = dasha_res.primary_windows[0].model_dump() if dasha_res.primary_windows else None

        eval_kp: MethodEvaluation = kp_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)
        eval_vedic: MethodEvaluation = vedic_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)
        eval_bnn: MethodEvaluation = bnn_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)
        eval_pyth: MethodEvaluation = pythagorean_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)
        eval_vnum: MethodEvaluation = vedic_numerology_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)
        eval_lk: MethodEvaluation = lal_kitab_adapter.evaluate(intent.model_dump(), eval_profile, chart_facts.model_dump(), hypothesis_window)

        all_evaluations = [eval_kp, eval_vedic, eval_bnn, eval_pyth, eval_vnum, eval_lk]

        # Step 6: Deterministic Consensus Engine
        consensus: ConsensusResult = consensus_engine.derive_consensus(
            primary_numerology=dasha_res,
            evaluations=all_evaluations,
            event_definition=intent.model_dump()
        )

        # Step 7: Governed Remedies & Practical Grounding
        remedies: List[RemedyItem] = remedy_service.get_governed_remedies(
            event_family=intent.event_family,
            driver=dasha_res.driver,
            conductor=dasha_res.conductor,
            event_assessment=consensus.event_assessment
        )

        # Step 8: Citations & Source Evidence
        collected_evidence = []
        for ev in all_evaluations:
            for item in ev.rule_evidence:
                collected_evidence.append(item)
        validated_citations = source_governor.validate_citations(collected_evidence)

        # Step 9: Save Immutable Prediction Snapshot
        pred_id = f"PRED-{consensus.consensus_id[4:]}"
        snapshot = PredictionSnapshot(
            prediction_id=pred_id,
            user_id=user_id,
            created_at=datetime.now().isoformat(),
            event_definition_id=intent.event_definition_id,
            event_family=intent.event_family,
            driver=dasha_res.driver,
            conductor=dasha_res.conductor,
            personal_year=dasha_res.personal_year,
            verification_status=consensus.verification_status,
            event_assessment=consensus.event_assessment,
            primary_windows=[w.model_dump() for w in consensus.primary_windows],
            method_evaluations=[e.model_dump() for e in all_evaluations],
            citations=[dict(c) for c in validated_citations],
            policy_version=consensus.policy_version
        )
        outcome_service.save_snapshot(snapshot)

        # Step 10: Build 7-Tier Human-Friendly Response
        active_pd = next((p for p in dasha_res.periods if p.level == "PRATYANTARDASHA" and p.is_active), dasha_res.periods[2])
        first_name = (user_name.split()[0] if user_name else "Seeker").capitalize()
        primary_win = dasha_res.primary_windows[0] if dasha_res.primary_windows else None
        acute_window_str = f"{primary_win.start} to {primary_win.end}" if primary_win else "Calculated Dasha Window"

        consult_narrative = generate_humanized_consultation(
            user_name=user_name,
            question=message,
            driver=dasha_res.driver,
            conductor=dasha_res.conductor,
            personal_year=dasha_res.personal_year,
            active_dasha_planet=active_pd.ruling_planet,
            acute_window_start=primary_win.start if primary_win else None,
            acute_window_end=primary_win.end if primary_win else None,
            requested_horizon=intent.requested_horizon,
            verification_status=consensus.verification_status,
            event_assessment=consensus.event_assessment,
            lo_shu_grid=profile_facts.get("loshu_grid"),
            practical_actions=[r.description for r in remedies if r.category == "PRACTICAL_ACTION"]
        )

        human_friendly = HumanFriendlySummary(
            takeaway=(
                f"Your career momentum for {intent.event_definition.lower()} is governed by your primary "
                f"Numerology Dasha ({active_pd.ruling_planet} cycle, Personal Year {dasha_res.personal_year}). "
                f"Calculated acute execution window spans {acute_window_str}."
            ),
            timing_status=(
                f"Verification: {consensus.verification_status} · Assessment: {consensus.event_assessment} · "
                f"Requested Horizon: {intent.requested_horizon.replace('_', ' ')} (evaluated separately from calculated Dasha)"
            ),
            supported_by_report=(
                f"Driver {dasha_res.driver} and Conductor {dasha_res.conductor} establish strong institutional alignment. "
                f"The active {active_pd.ruling_planet} Pratyantardasha directly supports structured professional outreach."
            ),
            unconcluded_aspects=(
                "A natal Lo Shu grid alone does not establish job-offer dates. Astrological cross-checks corroborate potential, "
                "but cannot guarantee corporate hiring decisions without proactive executive execution. Lal Kitab remains gated."
            ),
            missing_inputs_explanation=(
                f"Birth date ({day}-{month}-{year}) confirmed and processed. Optional birth time ({tob or 'not supplied'}) "
                f"and city ({pob or 'not supplied'}) were used for topocentric ephemeris checks."
            ),
            practical_actions=consult_narrative.get("practical_actions") or [r.description for r in remedies if r.category == "PRACTICAL_ACTION"],
            followup_question=(
                consult_narrative.get("followup_question") or
                f"Would you like to examine specific tactical interview timings during the {acute_window_str} execution window?"
            ),
            full_dialogue_text=consult_narrative.get("full_dialogue_text"),
            driver_title=consult_narrative.get("driver_title"),
            driver_planet=consult_narrative.get("driver_planet"),
            conductor_title=consult_narrative.get("conductor_title")
        )

        direct_text = consult_narrative.get("full_dialogue_text") or (
            f"Namaste {first_name} 🙏\n\n"
            f"**1. Career Takeaway:** {human_friendly.takeaway}\n\n"
            f"**2. Timing Status & Verification:** {human_friendly.timing_status}\n\n"
            f"**3. Supported by Verified Data:** {human_friendly.supported_by_report}\n\n"
            f"**4. What Cannot Yet Be Concluded:** {human_friendly.unconcluded_aspects}\n\n"
            f"**5. Input & Calculation Trace:** {human_friendly.missing_inputs_explanation}\n\n"
            f"**6. Practical Next Steps:**\n• " + "\n• ".join(human_friendly.practical_actions) + f"\n\n"
            f"**7. Next Step:** {human_friendly.followup_question}"
        )

        method_evidence_vm = []
        for ev in all_evaluations:
            cits = [
                {"sourceId": c["source_id"], "title": c["title"], "locator": c["locator"]}
                for c in ev.rule_evidence
            ]
            method_evidence_vm.append({
                "methodId": ev.method_id,
                "assessment": ev.assessment,
                "summary": ev.candidate_windows[0].get("label", "Evaluation complete") if ev.candidate_windows else "Not evaluated in consensus",
                "citations": cits
            })

        pred_vm = CharmPredictionViewModel(
            prediction_id=pred_id,
            primary_method="NUMEROLOGY_DASHA",
            verification_status=consensus.verification_status,
            event_assessment=consensus.event_assessment,
            requested_horizon=intent.requested_horizon,
            primary_windows=[w.model_dump() for w in consensus.primary_windows],
            numerology_summary=f"Natal Driver {dasha_res.driver}, Conductor {dasha_res.conductor}, traversing Personal Year {dasha_res.personal_year}.",
            corroboration_summary=consensus.summary,
            provenance_record=dasha_res.provenance_record,
            missing_requirements={
                "available_inputs": intent.available_inputs,
                "missing_inputs": intent.missing_inputs,
                "status": "ALL_REQUIRED_INPUTS_CONFIRMED"
            },
            limitations=[
                "Numerology Dasha represents cyclical potential and planetary archetypes, not scientifically predetermined certainty.",
                "Lal Kitab adapter is strictly disabled pending physical folio verification; Astro-Vastu does not vote on timing.",
                "Drugs and Magic Remedies Act 1954: Recommendations are lifestyle/spiritual attunements only."
            ],
            method_evidence=method_evidence_vm,
            practical_steps=human_friendly.practical_actions,
            optional_remedies=[
                {"title": r.title, "description": r.description, "citation": r.citation}
                for r in remedies if r.category != "PRACTICAL_ACTION"
            ],
            human_friendly=human_friendly.model_dump()
        )

        return CharmChatResponse(
            conversation_id=conv_id,
            message_id=msg_id,
            status="ANSWERED",
            assistant_message={
                "text": direct_text,
                "sections": [
                    {"title": "Career Takeaway", "content": human_friendly.takeaway},
                    {"title": "Verification & Consensus", "content": consensus.summary},
                    {"title": "Supported Findings", "content": human_friendly.supported_by_report},
                    {"title": "Boundaries & Limitations", "content": human_friendly.unconcluded_aspects}
                ]
            },
            input_validation={
                "available_inputs": intent.available_inputs,
                "missing_inputs": intent.missing_inputs,
                "provenance": dasha_res.provenance_record
            },
            numerology_dasha_result={
                "driver": dasha_res.driver,
                "conductor": dasha_res.conductor,
                "personal_year": dasha_res.personal_year,
                "primary_windows": [w.model_dump() for w in dasha_res.primary_windows],
                "active_period": active_pd.model_dump()
            },
            career_event_assessment={
                "goal": intent.event_type,
                "requested_horizon": intent.requested_horizon,
                "event_assessment": consensus.event_assessment,
                "event_rule": dasha_res.career_event_rule
            },
            cross_verification=[e.model_dump() for e in all_evaluations],
            consensus_status=consensus.verification_status,
            evidence_citations=[dict(c) for c in validated_citations],
            missing_requirements={
                "available_inputs": intent.available_inputs,
                "missing_inputs": intent.missing_inputs
            },
            human_friendly_summary=human_friendly.model_dump(),
            practical_next_steps=human_friendly.practical_actions,
            calculation_version="2.0.0",
            audit_trace_id=trace_id,
            prediction=pred_vm.model_dump(),
            follow_up_question=human_friendly.followup_question,
            safety_flags=[]
        )

charm_chat_orchestrator = CharmChatOrchestrator()
