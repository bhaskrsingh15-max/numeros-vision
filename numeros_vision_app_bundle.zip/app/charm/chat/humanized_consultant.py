"""
app/charm/chat/humanized_consultant.py
======================================
Humanized Master Numerologist Consultation Narrative Generator.

Translates 100% deterministic calculation results (Driver, Conductor,
Personal Year, Mahadasha, Antardasha, acute Pratyantardasha timing windows,
planetary transits, BNN conjunctions, and Lo Shu grid) into warm, natural,
conversational explanations—as if the user is sitting across from a wise,
empathetic, seasoned human numerologist.

Zero hallucinated dates or arithmetic: all numerical facts are sourced
strictly from the deterministic calculation engine.
"""

from typing import Dict, Any, List, Optional
import re

PLANET_NAMES = {
    1: "Sun (Surya)",
    2: "Moon (Chandra)",
    3: "Jupiter (Guru)",
    4: "Rahu (North Node)",
    5: "Mercury (Budh)",
    6: "Venus (Shukra)",
    7: "Ketu (South Node)",
    8: "Saturn (Shani)",
    9: "Mars (Mangal)"
}

DRIVER_ESSENCE = {
    1: {
        "title": "Natural Leader & Pioneer",
        "ruler": "the Sun (Surya)",
        "gift": "executive authority, pioneering courage, and an instinct to initiate breakthroughs",
        "blindspot": "impatience with slow team members or feeling suffocated under micromanagement",
        "stuck_reason": "feeling stuck usually happens when your natural authority is suppressed in rigid bureaucracy or when you try to force outcomes before the cycle matures",
        "unblock_action": "step into ownership of a high-visibility project, reframe your executive pitch, and stop waiting for passive permission from hesitant stakeholders"
    },
    2: {
        "title": "Intuitive Diplomat & Harmonizer",
        "ruler": "the Moon (Chandra)",
        "gift": "deep emotional intelligence, collaborative negotiation, and creative insight",
        "blindspot": "absorbing team anxieties, taking workplace politics to heart, and second-guessing your decisions",
        "stuck_reason": "stagnation occurs when emotional fatigue clouds your confidence or when self-doubt causes you to hesitate on applying for higher roles",
        "unblock_action": "separate your emotional boundaries from team stress, lean on structured data rather than mood, and partner with confident decision-makers"
    },
    3: {
        "title": "Creative Strategist & Visionary Counselor",
        "ruler": "Jupiter (Guru)",
        "gift": "expansive wisdom, compelling communication, and the ability to mentor and scale ideas",
        "blindspot": "scattering mental energy across too many ideas and resisting repetitive operational follow-through",
        "stuck_reason": "feeling blocked happens when your creative voice is ignored or when you disperse focus into five ventures at once without closing any",
        "unblock_action": "pick one flagship expertise area, publish your strategic point of view, and schedule 3 high-impact executive conversations"
    },
    4: {
        "title": "Architect of Modern Systems & Unconventional Thinker",
        "ruler": "Rahu",
        "gift": "non-linear problem-solving, architectural mastery, and seeing market flaws long before others",
        "blindspot": "friction with slow traditional management and sudden pacing swings between intense focus and frustration",
        "stuck_reason": "you feel stuck when your ideas live 12 months ahead of conventional environments, causing bureaucratic gatekeepers to stall your momentum",
        "unblock_action": "translate your visionary ideas into simple risk-reward metrics that traditional bosses can easily approve, and avoid abrupt arguments with leadership"
    },
    5: {
        "title": "Dynamic Commercial Catalyst & Quick Communicator",
        "ruler": "Mercury (Budh)",
        "gift": "rapid adaptability, commercial negotiation, and effortless networking agility",
        "blindspot": "restlessness with long routine projects and abandoning outreach just before traction locks in",
        "stuck_reason": "blockages appear when you jump from one opportunity to the next out of impatience, resetting your compounding momentum prematurely",
        "unblock_action": "commit to one specific career channel for 60 unbroken days, follow up on pending recruiter conversations, and leverage your persuasive charm"
    },
    6: {
        "title": "Diplomatic Leader & High-Standard Orchestrator",
        "ruler": "Venus (Shukra)",
        "gift": "aesthetic excellence, relationship magnetism, and building high-trust, elite environments",
        "blindspot": "over-accommodating team demands, taking on emotional guilt, and hesitating to demand your true market worth",
        "stuck_reason": "feeling stuck is almost always a result of carrying silent team burdens, tolerating undervalued compensation, or experiencing transitional friction where your cycle demands you shed mismatched commitments",
        "unblock_action": "conduct a ruthless calendar audit to eliminate low-leverage obligations, re-engage 3 senior executive connections who appreciate quality, and hold firm on your worth without apologetic compromises"
    },
    7: {
        "title": "Deep Analytical Specialist & Truth Seeker",
        "ruler": "Ketu",
        "gift": "profound technical depth, independent research, and seeing through superficial corporate posturing",
        "blindspot": "withdrawing into silence when misunderstood and avoiding proactive self-advocacy or networking",
        "stuck_reason": "stuckness occurs during introspective purification cycles where old roles lose meaning, forcing you to seek substantive, intellectually autonomous work",
        "unblock_action": "document your specialized domain expertise into an authoritative case study, reach out directly to technical founders/specialist leaders, and maintain daily morning centering"
    },
    8: {
        "title": "Executive Authority & Structural Compounding Master",
        "ruler": "Saturn (Shani)",
        "gift": "unshakeable resilience, long-term institutional vision, and steering high-stakes complexity to victory",
        "blindspot": "internalizing heavy burdens without asking for support, and assuming delays mean personal failure",
        "stuck_reason": "delays are not denials—they are Saturn's crucible testing your structural foundation so that your next position carries real, unshakeable authority rather than a hollow title",
        "unblock_action": "document all key contributions in clear written metrics, maintain steady weekly outreach without emotional panic, and trust that your compounding endurance always wins in the end"
    },
    9: {
        "title": "Dynamic Pioneer & High-Impact Initiator",
        "ruler": "Mars (Mangal)",
        "gift": "fearless drive, protective leadership, and mobilizing teams to conquer difficult challenges",
        "blindspot": "impulsive reactions when stalled and burning bridges out of righteous indignation",
        "stuck_reason": "feeling blocked happens when administrative red tape slows your warrior drive, tempting you to make abrupt, angry exits rather than calculated strategic pivots",
        "unblock_action": "channel excess fire into intense physical conditioning, pause 24 hours before responding to frustrating workplace friction, and target roles with high mission impact and autonomous execution"
    }
}

PERSONAL_YEAR_GUIDANCE = {
    1: "A powerful year of new beginnings and seed-planting. Energy is shifting in your favor for bold initiatives.",
    2: "A year of diplomacy, patience, and strategic partnerships. Progress happens through quiet alliances rather than solo brute force.",
    3: "A year of creative expansion, self-expression, and social visibility. Your voice and presentations carry special weight.",
    4: "A disciplined foundation-building year. Progress requires solid processes, skill certification, and meticulous groundwork.",
    5: "A dynamic year of sudden shifts, travel, and unexpected opportunities. Stay flexible and ready to pivot quickly.",
    6: "A year of karmic realignment, family responsibility, and professional elevation. You are stepping into true mentorship and leadership.",
    7: "A contemplative year of deep specialization and inner audit. Quality and technical mastery supersede rapid outward expansion.",
    8: "A major harvest and karmic manifestation year. Financial and executive authority are primed to crystallize.",
    9: "A year of completion, clearing out obsolete ties, and shedding what no longer serves your future growth."
}

def generate_humanized_consultation(
    user_name: str,
    question: str,
    driver: int,
    conductor: int,
    personal_year: int,
    active_dasha_planet: str,
    acute_window_start: Optional[str] = None,
    acute_window_end: Optional[str] = None,
    requested_horizon: str = "unspecified_horizon",
    verification_status: str = "NUMEROLOGY_PRIMARY_CORROBORATED",
    event_assessment: str = "FAVOURABLE",
    lo_shu_grid: Optional[Dict[str, Any]] = None,
    practical_actions: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Synthesizes deterministic calculations into a warm, wise, natural human consultation.
    """
    first_name = (user_name.split()[0] if user_name and user_name.lower() != "seeker" else "").capitalize()
    greeting_name = f" {first_name}" if first_name else ""
    ql = question.lower()

    d_info = DRIVER_ESSENCE.get(driver, DRIVER_ESSENCE[1])
    c_info = DRIVER_ESSENCE.get(conductor, DRIVER_ESSENCE[1])
    py_text = PERSONAL_YEAR_GUIDANCE.get(personal_year, "A pivotal cycle of personal growth and professional alignment.")

    has_dates = bool(acute_window_start and acute_window_end and acute_window_start != "0000-00-00")
    timing_str = f"**{acute_window_start}** to **{acute_window_end}**" if has_dates else "the upcoming transition window"

    is_driver_query = any(w in ql for w in ["driver", "birth number", "mulank", "what does my number say", "my numbers say"]) and not any(w in ql for w in ["stuck", "blocked", "unblock", "lost"])
    is_stuck_query = any(w in ql for w in ["stuck", "block", "blocked", "unblock", "lost opportunity", "lost job", "missed opportunity", "delay", "struggling", "frustrated", "pause", "stagnation", "stagnant"]) or ("opportunity" in ql and any(w in ql for w in ["lost", "missed", "lack", "no"]))
    is_promotion_query = any(w in ql for w in ["promotion", "promoted", "hike", "appraisal", "director", "senior role", "next level"])
    is_career_change_query = any(w in ql for w in ["change career", "switch career", "switch field", "pivot", "different industry", "career change"])
    is_business_query = any(w in ql for w in ["business", "startup", "venture", "freelance", "founder", "consultancy", "own company", "own firm"])

    # 1. Empathetic Opening & Diagnosis
    if is_driver_query:
        opening = (
            f"Namaste{greeting_name} 🙏 Let us explore your sacred birth vibration. "
            f"In classical Indian Sankhya Shastra, your Birth Number (Driver / Mulank {driver}) represents your core soul identity, "
            f"your natural operational instinct, and how you command authority in the professional world."
        )
        core_logic = (
            f"As a **Driver {driver} governed by {d_info['ruler']}**, you are fundamentally a **{d_info['title']}**. "
            f"Your natural superpowers in career are {d_info['gift']}. You flourish when given creative or operational autonomy. "
            f"Coupled with your **Life Path (Conductor) {conductor} ({c_info['ruler']})**, your destiny calls you toward {c_info['title']} roles. "
            f"Right now in 2026, you are navigating **Personal Year {personal_year}** ({py_text}), which accelerates your natural strengths "
            f"provided you avoid your classic vulnerability: {d_info['blindspot']}."
        )
    elif is_stuck_query:
        opening = (
            f"Namaste{greeting_name} 🙏 Please take a deep breath. I want to reassure you right away: "
            f"feeling stuck and sensing missed opportunities is deeply frustrating, but looking at your numbers, "
            f"this is not a personal failure or a dead end. In authentic classical numerology, stagnation is almost always "
            f"a sign that an old energetic cycle has expired while your next leadership phase is recalibrating."
        )
        core_logic = (
            f"Here is the exact logic in your numbers: You are guided by **Driver {driver} ({d_info['ruler']})** "
            f"and **Conductor {conductor} ({c_info['ruler']})**. As a Driver {driver}, your natural gift is {d_info['gift']}. "
            f"However, {d_info['stuck_reason']}. "
            f"Currently in 2026, you are moving through **Personal Year {personal_year}**, while your active timing cycle is influenced by **{active_dasha_planet}**. "
            f"This creates a natural friction: your core energy wants to push forward, but this cycle is acting as a celestial filter, "
            f"clearing out mismatched compromise roles so you can step into genuine, long-term professional authority."
        )
    elif is_career_change_query:
        opening = (
            f"Namaste{greeting_name} 🙏 Considering a career pivot is a profound moment of self-recalibration. "
            f"Let us look at what your numbers and active cycles reveal about your transition readiness."
        )
        core_logic = (
            f"As a **Driver {driver} governed by {d_info['ruler']}**, you are fundamentally a **{d_info['title']}**. "
            f"Your natural gift is {d_info['gift']}. Coupled with your **Life Path (Conductor) {conductor} ({c_info['ruler']})**, "
            f"you thrive when your work aligns with genuine autonomy and purpose. "
            f"Currently in 2026, traversing **Personal Year {personal_year}** ({py_text}), transitions are most sustainable "
            f"when you bridge existing domain competencies methodically into the new field rather than making abrupt, ungrounded leaps."
        )
    elif is_business_query:
        opening = (
            f"Namaste{greeting_name} 🙏 Venturing into independent enterprise is a sacred milestone. "
            f"Let us examine how your birth vibrations and current cycles support entrepreneurial initiative."
        )
        core_logic = (
            f"Your foundational **Driver {driver} ({d_info['ruler']})** gives you {d_info['gift']}, while **Conductor {conductor}** "
            f"shapes your long-term commercial reputation. In 2026, navigating **Personal Year {personal_year}**, the active cycle of "
            f"**{active_dasha_planet}** tests your operational resilience. Business success in your blueprint is unlocked through "
            f"disciplined risk management, strategic domain focus, and strong ethical governance."
        )
    elif is_promotion_query:
        opening = (
            f"Namaste{greeting_name} 🙏 Let us look closely at your promotion and advancement timeline. "
            f"Career elevation is never an accident of luck; it happens when your personal energetic cycle aligns with an active Dasha window."
        )
        core_logic = (
            f"Your foundational Driver {driver} ({d_info['ruler']}) paired with Conductor {conductor} gives you strong institutional presence. "
            f"In 2026, navigating Personal Year {personal_year}, the planetary transit of {active_dasha_planet} is actively testing your readiness "
            f"for senior leadership. The key to securing your promotion is not overworking in silence, but stepping into visible strategic ownership "
            f"and documenting your measurable business impact."
        )
    else:
        opening = (
            f"Namaste{greeting_name} 🙏 Welcome. Let us examine the authentic planetary and numerical currents governing your path. "
            f"Your questions are meaningful, and your numbers hold clear, grounded guidance."
        )
        core_logic = (
            f"Your birth blueprint combines **Driver {driver} ({d_info['ruler']})** with **Conductor {conductor} ({c_info['ruler']})**. "
            f"This blend gives you {d_info['gift']}, while your Conductor drives you toward {c_info['gift']}. "
            f"Currently, your **Personal Year {personal_year}** ({py_text}) sets the backdrop, while your acute sub-cycle under **{active_dasha_planet}** "
            f"governs your immediate day-to-day decisions."
        )

    # 2. Timing Window Logic
    if has_dates:
        timing_explanation = (
            f"In our classical Dasha calculations, your strongest acute window of breakthrough runs from {timing_str}. "
            f"During this window, the current friction clears, making it the most auspicious period to schedule crucial interviews, "
            f"negotiate compensation, pitch high-stakes proposals, or launch a new career venture. "
            f"Your requested forecast horizon ({requested_horizon.replace('_', ' ')}) maps directly into this active cycle."
        )
    else:
        timing_explanation = (
            f"To calculate your acute, day-by-day Dasha timing windows with exact calendar precision, ensure your full date of birth "
            f"is verified. Even at a broad cycle level, your Personal Year {personal_year} confirms that steady foundational actions "
            f"taken now will yield tangible recognition as the cycle matures."
        )

    # 3. Practical Grounded Actions (Grounding First)
    default_actions = [
        d_info['unblock_action'],
        "Conduct a focused 3-point outreach: reach out directly to 3 former mentors or trusted colleagues with a brief, value-centered message.",
        "Align your workspace: face North or East while working, and remove desk clutter to clear energetic and mental stagnation."
    ]
    actions = []
    if practical_actions:
        actions.extend(practical_actions)
    for act in default_actions:
        if act not in actions and len(actions) < 3:
            actions.append(act)

    actions_formatted = "\n".join(f"• **Step {i+1}:** {act}" for i, act in enumerate(actions[:3]))

    # 4. Human Follow-Up
    if is_stuck_query:
        followup = f"Does this explanation help you understand the deeper rhythm behind this temporary pause? Would you like to look at specific interview dates during your {timing_str} window?"
    elif is_driver_query:
        followup = f"Would you like to examine which career industries or executive paths resonate most powerfully with your Driver {driver} and Conductor {conductor} vibration?"
    elif is_career_change_query:
        followup = f"Would you like to explore which new industries or roles align most harmoniously with your Life Path {conductor} and Driver {driver}?"
    elif is_business_query:
        followup = "Would you like to check the numerological alignment of your proposed business name or evaluate auspicious founding launch windows?"
    elif is_promotion_query:
        followup = f"Would you like to look at the upcoming high-visibility weeks during your {timing_str} window to schedule your appraisal conversation?"
    else:
        followup = f"Would you like to examine your specific favorable days of the week or look into your missing Lo Shu numbers to accelerate this alignment?"

    humanized_takeaway = (
        f"Your career momentum is governed by your primary Numerology Dasha "
        f"({active_dasha_planet} cycle, Personal Year {personal_year}). "
        f"Calculated acute execution window spans {timing_str}. "
        f"You are a Driver {driver} ({d_info['title']}) navigating Personal Year {personal_year}."
    )
    humanized_timing_status = (
        f"Verification: {verification_status} · Assessment: {event_assessment} · "
        f"Requested Horizon: {requested_horizon.replace('_', ' ')} (evaluated separately from calculated Dasha) · "
        f"Timing Window: {timing_str} ({active_dasha_planet} Cycle)"
    )
    humanized_supported = (
        f"Driver {driver} and Conductor {conductor} establish strong institutional alignment ({d_info['gift']}). "
        f"The active {active_dasha_planet} Pratyantardasha directly supports structured professional outreach."
    )
    humanized_unconcluded = (
        "A natal Lo Shu grid alone does not establish job-offer dates. Astrological cross-checks corroborate potential, "
        "but cannot guarantee corporate hiring decisions without proactive executive execution. Lal Kitab remains gated."
    )

    full_dialogue_text = (
        f"{opening}\n\n"
        f"**1. The Logic Behind Your Numbers:**\n{core_logic}\n\n"
        f"**2. Your Timing & Breakthrough Horizon:**\n{timing_explanation}\n\n"
        f"**3. Three Practical Actions to Unblock Your Growth:**\n{actions_formatted}\n\n"
        f"**✦ Counsel from the Master:**\n{followup}"
    )

    return {
        "takeaway": humanized_takeaway,
        "timing_status": humanized_timing_status,
        "supported_by_report": humanized_supported,
        "unconcluded_aspects": humanized_unconcluded,
        "timing_explanation": timing_explanation,
        "full_dialogue_text": full_dialogue_text,
        "practical_actions": actions[:3],
        "followup_question": followup,
        "driver_title": d_info["title"],
        "driver_planet": d_info["ruler"],
        "conductor_title": c_info["title"]
    }
