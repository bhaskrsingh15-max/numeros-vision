"""
Razorpay Payment Integration — Numeros Vision
POST /api/v1/payments/create-order   → create Razorpay order
POST /api/v1/payments/verify         → verify payment signature (called client-side after success)
GET  /api/v1/payments/plans          → public pricing catalogue
"""

import os
import hmac
import hashlib
import json
import time
from typing import Optional, Dict, Any, List, Tuple
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from app.engine.monetization_alignment_engine import (
    analyze_user_alignment_and_gaps,
    is_staging_bypass_authorized
)
from app.engine.funnel_service import (
    PricePolicy,
    digit_root,
    validate_single_price,
    validate_price_pair,
    FunnelStage,
    JourneyState,
    JourneyContext,
    get_next_step,
    log_funnel_event,
    PRODUCT_FUNNEL_CATALOG,
)
from app.api.auth import (
    update_user_entitlements,
    get_user_account_by_identifier,
    _ACTIVE_SESSIONS,
    _USER_ACCOUNTS
)

router = APIRouter(prefix="/api/v1/payments", tags=["payments"])

# ── Razorpay credentials (set in environment) ─────────────────────────────
# Test keys:  rzp_test_XXXXXXXXXXXXXXXXXXXX  /  your_test_secret
# Live keys:  rzp_live_XXXXXXXXXXXXXXXXXXXX  /  your_live_secret
RAZORPAY_KEY_ID         = os.getenv("RAZORPAY_KEY_ID", "rzp_test_REPLACE_ME")
RAZORPAY_KEY_SECRET     = os.getenv("RAZORPAY_KEY_SECRET", "REPLACE_ME_SECRET")
RAZORPAY_WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", RAZORPAY_KEY_SECRET)

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))
SESSIONS_FILE = os.path.join(DATA_DIR, "verified_sessions.json")

# ── Plan catalogue ─────────────────────────────────────────────────────────
PLANS = {
    "starter_5q": {
        "name":        "Starter — 5 Questions",
        "amount_inr":  95,
        "original_price_inr": 199,
        "amount_paise": 9500,          # Razorpay uses smallest currency unit (paise)
        "period":      "5 Questions",
        "questions_count": 5,
        "has_remedies": False,
        "description": "5 question predictions of any user queries",
        "features": [
            "5 In-depth Question Predictions",
            "Anviel Every Charm Alignment & Timing",
            "Valid across Career, Love, Wealth & Health",
            "Instant Charm AI answers 24/7",
        ]
    },
    "growth_10q": {
        "name":        "Growth — 10 Questions + Remedies",
        "amount_inr":  399,
        "original_price_inr": 599,
        "amount_paise": 39900,
        "period":      "10 Questions + Remedies",
        "questions_count": 10,
        "has_remedies": True,
        "description": "10 questions predictions with customized remedies for all 10 questions",
        "features": [
            "10 In-depth Question Predictions",
            "Custom Remedies for all 10 questions",
            "Auspicious timing & lucky dates",
            "Gemstone & practical energy rituals",
            "Priority Charm AI response",
        ]
    },
    "complete_report": {
        "name":        "Complete Reports & Remedies",
        "amount_inr":  1050,
        "original_price_inr": 1299,
        "amount_paise": 105000,
        "period":      "Complete Access",
        "questions_count": 9999,
        "has_remedies": True,
        "description": "Complete destiny reports and comprehensive remedies",
        "features": [
            "Complete Personal Destiny Blueprint Report",
            "Comprehensive Multi-Layer Remedies",
            "Personalized Vedic Gemstone Prescription",
            "Annual Timing Forecast & Life Roadmap",
            "Unlimited Question Predictions with Remedies",
            "Downloadable PDF Personal Report",
        ]
    },
    # ── 1. NUMEROLOGY REPORT PACKAGES (3 TIERS) ─────────────────────────────
    "report_essential": {
        "name":        "Essential Cosmic Blueprint",
        "amount_inr":  199,
        "original_price_inr": 399,
        "amount_paise": 19900,
        "period":      "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "report",
        "description": "Core Identity, Mulank & Bhagyank, basic Lo Shu 3x3 Grid, 1-year snapshot & primary color/gemstone guide",
        "features": [
            "12-15 Page Executive PDF Report",
            "Mulank (Driver) & Bhagyank (Conductor) Blueprint",
            "Lo Shu 3x3 Grid & Missing Numbers audit",
            "1-Year Personal Timing Snapshot",
            "Primary Gemstone & Color Harmony Guide"
        ]
    },
    "report_master": {
        "name":        "Master Dual-System Synthesis Report",
        "amount_inr":  510,
        "original_price_inr": 999,
        "amount_paise": 51000,
        "period":      "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "report",
        "description": "Complete 35+ Page Dual-System Blueprint (Chaldean + BNN + 5-Year Vimshottari Dasha + 7-Layer Safe Remedies)",
        "features": [
            "35-40 Page Master Synthesis Dossier",
            "Full Name vs Calling Name Chaldean audit",
            "BNN 1-5-9 Trines & 2-12 Wealth Vector Analysis",
            "5-Year 5-Tier Vimshottari Dasha Timeline",
            "Historical Milestone Accuracy Calibration",
            "7-Layer Safe Remedies (Mantra, Daan, Crystal, Lifestyle)",
            "Mobile Number & Digital Touchpoint Audit"
        ]
    },
    "report_divine": {
        "name":        "Divine Sovereign Life Roadmap",
        "amount_inr":  1050,
        "original_price_inr": 1999,
        "amount_paise": 105000,
        "period":      "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "report",
        "description": "Comprehensive 55+ Page Sovereign Blueprint with KP Sub-Lord significators, 10-Year Macro Timing Map & Family Compatibility",
        "features": [
            "55-65 Page Sovereign Executive Blueprint",
            "All Master Synthesis features + KP Sub-Lord significators",
            "10-Year Macro Planetary Timing Radar",
            "Deep Historical Milestone Calibration (Up to 3 events)",
            "3 Alternative Name Spelling Optimizations",
            "Mobile + Vehicle Plate + House Energy Audit",
            "Couple / Business Partner Compatibility Add-on",
            "Priority Processing & High-Resolution Vector Charts"
        ]
    },
    # ── 2. AI QUESTION CREDITS & SUBSCRIPTIONS ──────────────────────────────
    "ai_starter_5q": {
        "name":        "Charm AI — Starter Pack (5 Questions)",
        "amount_inr":  95,
        "original_price_inr": 199,
        "amount_paise": 9500,
        "period":      "5 Questions",
        "questions_count": 5,
        "has_remedies": False,
        "category":    "ai_credits",
        "description": "5 targeted Charm AI question predictions across Career, Love, Wealth or Health",
        "features": [
            "5 Targeted Charm AI Predictions",
            "Cross-engine consensus verification",
            "Valid across Career, Marriage, Wealth & Health",
            "Instant 24/7 grounded response"
        ]
    },
    "ai_growth_15q": {
        "name":        "Charm AI — Growth Pack (15 Questions + Remedies)",
        "amount_inr":  249,
        "original_price_inr": 499,
        "amount_paise": 24900,
        "period":      "15 Questions + Remedies",
        "questions_count": 15,
        "has_remedies": True,
        "category":    "ai_credits",
        "description": "15 deep question predictions with customized safe remedies and auspicious timing",
        "features": [
            "15 In-depth Question Predictions",
            "Customized 7-Layer Safe Remedies for each query",
            "Auspicious timing windows & lucky dates",
            "Priority Charm AI response speed"
        ]
    },
    "ai_power_35q": {
        "name":        "Charm AI — Power Pack (35 Questions + Auspicious Timing)",
        "amount_inr":  499,
        "original_price_inr": 899,
        "amount_paise": 49900,
        "period":      "35 Questions + Remedies",
        "questions_count": 35,
        "has_remedies": True,
        "category":    "ai_credits",
        "description": "35 comprehensive question predictions for active decision-makers making complex life pivots",
        "features": [
            "35 Comprehensive In-depth Predictions",
            "Full planetary transit & Dasha overlap analysis",
            "Personalized daily auspicious decision windows",
            "Rollover credits valid for 12 months"
        ]
    },
    "sub_monthly": {
        "name":        "Cosmic Timing Engine — Monthly Pass",
        "amount_inr":  149,
        "original_price_inr": 299,
        "amount_paise": 14900,
        "period":      "Monthly Recurring",
        "questions_count": 10,
        "has_remedies": True,
        "category":    "subscription",
        "description": "Continuous monthly transit alerts, monthly auspicious Muhurat calendar, and 10 monthly AI questions",
        "features": [
            "Weekly Gochar (Transit) alerts to WhatsApp/Email",
            "Monthly Auspicious Muhurat Action Calendar",
            "10 Monthly Charm AI questions (rollover enabled)",
            "20% discount on physical remedies & consultations"
        ]
    },
    "sub_annual": {
        "name":        "Cosmic Timing Engine — Annual VIP Pass",
        "amount_inr":  999,
        "original_price_inr": 1788,
        "amount_paise": 99900,
        "period":      "Annual Recurring (Save 44%)",
        "questions_count": 150,
        "has_remedies": True,
        "category":    "subscription",
        "description": "Complete 365-day planetary transit radar, monthly calendars, and 150 annual question credits",
        "features": [
            "365 Days of Personalized Planetary Transit Alerts",
            "12 Monthly Auspicious Muhurat Action Calendars",
            "150 Charm AI Question Credits",
            "Complimentary Master Synthesis PDF Report (₹510 value)",
            "Priority VIP customer support"
        ]
    },
    # ── 3. AI + REPORT INTERACTIVE COMBO ────────────────────────────────────
    "ai_report_combo": {
        "name":        "Interactive Charm AI + Master Report Combo",
        "amount_inr":  699,
        "original_price_inr": 1498,
        "amount_paise": 69900,
        "period":      "Report + Interactive Charm AI",
        "questions_count": 25,
        "has_remedies": True,
        "category":    "combo",
        "description": "35-Page Master PDF Report PLUS interactive conversational Charm AI loaded with your exact chart tokens",
        "features": [
            "35-40 Page Master Dual-System PDF Report (Instant download)",
            "Interactive Charm AI Chart Companion (Talk directly to your report)",
            "25 Pre-loaded questions to interrogate your chart and predictions",
            "Zero-hallucination answers bound strictly to your verified chart tokens",
            "Custom 7-Layer Safe Remedy Matrix"
        ]
    },
    # ── 4. PERSONAL CONSULTATION & SACRED GEOMETRY ADVISORY ─────────────────
    "advisory_personal_name": {
        "name":        "Personal Name Balancing & Spelling Calibration",
        "amount_inr":  1499,
        "original_price_inr": 2499,
        "amount_paise": 149900,
        "period":      "Advisory Dossier",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "advisory",
        "description": "Full Chaldean + Pythagorean vibration audit of legal and calling names with 3 optimal harmonized variations",
        "features": [
            "Legal Name vs Calling Name vibrational coherence audit",
            "Elimination of karmic debt compound numbers (13, 14, 16, 19, 28)",
            "3 Optimal Harmonized Spelling Variations",
            "Social signature, LinkedIn & email handle optimization guide",
            "Official gazette & affidavit spelling transition checklist"
        ]
    },
    "advisory_business_name": {
        "name":        "Commercial Entity & Brand Matrix",
        "amount_inr":  5999,
        "original_price_inr": 14000,
        "amount_paise": 599900,
        "period":      "Corporate Advisory",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "advisory",
        "description": "Full corporate GST registration alignment, trademark entity vibration, brand geometry, and multi-partner synastry audit",
        "features": [
            "Corporate Legal Name & Trade Name vibration audit",
            "Founder & Co-Founder Synergy Compatibility Matrix",
            "Incorporation & Launch Muhurat (3 high-probability dates)",
            "Bank Account & Invoicing numerical vibration audit",
            "Domain name & brand moniker numerical audit"
        ]
    },
    "advisory_brand_logo": {
        "name":        "Brand Logo Balancing & Sacred Geometry Harmony",
        "amount_inr":  9999,
        "original_price_inr": 15000,
        "amount_paise": 999900,
        "period":      "Executive Branding Dossier",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "advisory",
        "description": "5-Element sacred geometric vector audit, planetary color harmonization, upward trajectory verification, and 3 logo vectors",
        "features": [
            "5-Element Geometric Vector Energy Audit (Earth/Water/Fire/Air)",
            "Planetary Color Vector Harmonization aligned with Founders' charts",
            "Upward-right growth trajectory vector verification",
            "Yantra sacred geometry proportion alignment",
            "3 Finalized Balanced Vector Logo Concepts (SVG / AI / PNG)",
            "Complete Brand Sacred Geometry Guidelines PDF"
        ]
    },
    # ── 5. B2B SAAS SOFTWARE ACCESS & WHITELABEL ───────────────────────────
    "b2b_consultant_pro": {
        "name":        "B2B SaaS — Consultant Pro (Monthly)",
        "amount_inr":  2499,
        "original_price_inr": 4999,
        "amount_paise": 249900,
        "period":      "Monthly B2B SaaS",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "b2b",
        "description": "White-label calculation engine & branded PDF generation for professional astrologers and numerologists",
        "features": [
            "150 White-Label PDF Reports per month (Custom logo & branding)",
            "Sub-150ms deterministic Swiss Ephemeris & Numerology calculation",
            "Client management portal & historical chart database",
            "Overage: ₹15 per additional report"
        ]
    },
    "b2b_platform_growth": {
        "name":        "B2B SaaS — Platform Growth API (Monthly)",
        "amount_inr":  9999,
        "original_price_inr": 14999,
        "amount_paise": 999900,
        "period":      "Monthly API Access",
        "questions_count": 0,
        "has_remedies": True,
        "category":    "b2b",
        "description": "High-volume REST API for matrimonial portals, dating apps, wellness startups, and HR recruiting platforms",
        "features": [
            "10,000 API calls per month included",
            "36-Point Ashtakoot Guna Milan + BNN Mars-Venus synergy endpoint",
            "Lo Shu compatibility & core matrix JSON response",
            "99.9% Uptime SLA with dedicated API key"
        ]
    },
    # Backwards-compatible aliases
    "starter": {
        "name":        "Starter — 5 Questions",
        "amount_inr":  95,
        "original_price_inr": 199,
        "amount_paise": 9500,
        "period":      "5 Questions",
        "questions_count": 5,
        "has_remedies": False,
        "description": "5 question predictions of any user queries",
        "features": ["5 In-depth Question Predictions", "Anviel Every Charm Alignment & Timing"]
    },
    "growth": {
        "name":        "Growth — 10 Questions + Remedies",
        "amount_inr":  399,
        "original_price_inr": 599,
        "amount_paise": 39900,
        "period":      "10 Questions + Remedies",
        "questions_count": 10,
        "has_remedies": True,
        "description": "10 questions predictions with customized remedies for all 10 questions",
        "features": ["10 In-depth Question Predictions", "Custom Remedies for all 10 questions"]
    },
    "complete": {
        "name":        "Complete Reports & Remedies",
        "amount_inr":  1050,
        "original_price_inr": 1299,
        "amount_paise": 105000,
        "period":      "Complete Access",
        "questions_count": 9999,
        "has_remedies": True,
        "description": "Complete destiny reports and comprehensive remedies",
        "features": ["Complete Personal Destiny Blueprint Report", "Comprehensive Multi-Layer Remedies"]
    },
    "phone_consult": {
        "name":        "Phone Consultation",
        "amount_inr":  2499,
        "original_price_inr": 2499,
        "amount_paise": 249900,
        "period":      "one-time",
        "questions_count": 0,
        "has_remedies": True,
        "description": "45-minute personal numerology consultation via phone",
        "features": [
            "45-minute personal session",
            "WhatsApp confirmation within 2 hours",
            "Post-call remedy summary PDF",
        ]
    },
    "personal_consult": {
        "name":        "1-on-1 Master Personal Consultation",
        "amount_inr":  11400,
        "original_price_inr": 24000,
        "amount_paise": 1140000,
        "period":      "one-time (90 min)",
        "questions_count": 0,
        "has_remedies": True,
        "description": "90-minute exclusive 1-on-1 master session with Master Numerologist, complete life roadmap, birth epoch verification, and 30-day WhatsApp guidance",
        "features": [
            "90-minute private master consultation (Video or In-person)",
            "Birth Epoch Verification & deep multi-system chart synthesis",
            "Custom hand-crafted remedy plan, yantra & gemstone prescription",
            "30-day direct priority WhatsApp guidance with Master Numerologist",
            "Comprehensive Deluxe Destiny Dossier PDF report",
            "Full session recording & actionable milestone roadmap",
        ]
    },
    "vip_consult": {
        "name":        "1-on-1 Master Personal Consultation",
        "amount_inr":  11400,
        "original_price_inr": 24000,
        "amount_paise": 1140000,
        "period":      "one-time (90 min)",
        "questions_count": 0,
        "has_remedies": True,
        "description": "90-minute exclusive 1-on-1 master session with Master Numerologist",
        "features": [
            "90-minute private master consultation",
            "Complete chart synthesis & 30-day priority WhatsApp support",
        ]
    },
    "ai_growth_10q": {
        "name":        "Charm AI Growth Pack",
        "amount_inr":  399,
        "original_price_inr": 599,
        "amount_paise": 39900,
        "period":      "10 Questions + Remedies",
        "questions_count": 10,
        "has_remedies": True,
        "description": "10 questions predictions with customized remedies for all 10 questions",
        "features": ["10 In-depth Question Predictions", "Custom Remedies for all 10 questions"]
    },
    "sovereign_blueprint": {
        "name":        "Sovereign Life Blueprint",
        "amount_inr":  1050,
        "original_price_inr": 1299,
        "amount_paise": 105000,
        "period":      "Comprehensive Detailed Report",
        "questions_count": 9999,
        "has_remedies": True,
        "description": "Comprehensive 32-Page Detailed Life Blueprint Report & 10-Year Radar",
        "features": ["Complete Comprehensive Detailed Report (32 Pages)", "Calling Name vs Legal Name Harmonization", "10-Year Comprehensive Karmic Forecast"]
    },
    "master_consult": {
        "name":        "Bespoke VIP Consultation",
        "amount_inr":  11400,
        "original_price_inr": 24000,
        "amount_paise": 1140000,
        "period":      "90m Private Video Session",
        "questions_count": 0,
        "has_remedies": True,
        "description": "90-minute exclusive 1-on-1 master session with Master Numerologist, birth epoch verification, and 30-day WhatsApp guidance",
        "features": ["90m Private Video Session", "Birth Epoch Verification", "Custom Yantra Blueprint", "30 Days Priority WhatsApp Guidance"]
    },
    "bespoke_vip_consultation": {
        "name":        "Bespoke VIP Consultation",
        "amount_inr":  11400,
        "original_price_inr": 24000,
        "amount_paise": 1140000,
        "period":      "90m Private Video Session",
        "questions_count": 0,
        "has_remedies": True,
        "description": "90-minute exclusive 1-on-1 master session with Master Numerologist, birth epoch verification, and 30-day WhatsApp guidance",
        "features": ["90m Private Video Session", "Birth Epoch Verification", "Custom Yantra Blueprint", "30 Days Priority WhatsApp Guidance"]
    },
    # ── 6. LIFE RELATIONSHIP HARMONIC DOMAIN PACKAGES ──
    # Domain 1: Sacred Union & Spousal Bond (Harmonic Root 6 · Devotion & Opulence)
    "report_union_tripwire": {
        "name": "Marital Harmony Gap Unblocker",
        "amount_inr": 105,
        "original_price_inr": 330,
        "amount_paise": 10500,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "2-Page Quick Action Guide · Sacred Shagun Dakshina",
        "features": [
            "Thought-Action Relationship Plane Audit",
            "Immediate Spousal Harmony Checklist",
            "Sattvic Friday Attunement Ritual",
            "Lucky Direction & Color Vibration"
        ]
    },
    "report_union_master": {
        "name": "Sacred Union & Luxury Dossier",
        "amount_inr": 510,
        "original_price_inr": 1500,
        "amount_paise": 51000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "12-Page Complete Dual-System Synthesis",
        "features": [
            "Full 12-Page Master Dossier with Gold Seals",
            "81-Pair Cosmic Synergy & Lo Shu 3x3 Grid",
            "Ishta Devata Sadhana & Consecrated Beej Mantra",
            "Annual Transit & Milestone Windows"
        ]
    },
    "report_union_sovereign": {
        "name": "Sovereign Couple Destiny Blueprint",
        "amount_inr": 5100,
        "original_price_inr": 10500,
        "amount_paise": 510000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "35-Page Master Life & Marriage Synchronization",
        "features": [
            "Complete 35-Page Sovereign Life & Couple Blueprint",
            "Chaldean Legal & Calling Name Harmonization",
            "Dual Synastry Cross-Matching for Partners",
            "1-Year AI Question Credits Included"
        ]
    },
    # Domain 2: Commercial Velocity & Market Flow (Harmonic Root 5 · Commerce & Velocity)
    "report_commerce_tripwire": {
        "name": "Cash Flow Gap & Velocity Unblocker",
        "amount_inr": 149,
        "original_price_inr": 410,
        "amount_paise": 14900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "2-Page Rapid Financial Action Brief",
        "features": [
            "Missing Number 5 & Cash Drainage Audit",
            "Rapid Commercial Negotiation Timing Windows",
            "Wednesday Sattvic Green Attunement",
            "Desk Alignment for Financial Fluidity"
        ]
    },
    "report_commerce_master": {
        "name": "Commercial Mastery Dossier",
        "amount_inr": 599,
        "original_price_inr": 1499,
        "amount_paise": 59900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "12-Page Enterprise & Trade Synthesis",
        "features": [
            "Full 12-Page Master Dossier with Gold Seals",
            "Commercial Lo Shu Plane Alignment (4-5-6 & 2-5-8)",
            "Commercial Flow Beej Mantra & Consecrated Yantra Placement",
            "Annual Business Timing & Expansion Radar"
        ]
    },
    "report_commerce_sovereign": {
        "name": "Enterprise Scaling & Brand Matrix",
        "amount_inr": 5999,
        "original_price_inr": 14000,
        "amount_paise": 599900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "35-Page Full Commercial Architecture Blueprint",
        "features": [
            "Complete 35-Page Commercial Blueprint",
            "GST Entity Name & Brand Acoustic Sound Alignment",
            "Co-Founder & Key Investor Synergy Matrix",
            "1-Year AI Question Credits Included"
        ]
    },
    # Domain 3: Executive Authority & Career Sovereignty (Harmonic Root 1 · Executive Sovereignty)
    "report_authority_tripwire": {
        "name": "Career Authority Gap Unblocker",
        "amount_inr": 199,
        "original_price_inr": 370,
        "amount_paise": 19900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "2-Page Executive Elevation Brief",
        "features": [
            "Authority Alignment & Office Politics Neutralization",
            "Promotion & Performance Appraisal Windows",
            "Morning Solar Vitality & Water Consecration Guide",
            "Executive East Desk Facing Vector"
        ]
    },
    "report_authority_master": {
        "name": "Sovereign Leadership Dossier",
        "amount_inr": 550,
        "original_price_inr": 1450,
        "amount_paise": 55000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "12-Page Executive Dual-System Synthesis",
        "features": [
            "Full 12-Page Master Dossier with Gold Seals",
            "81-Pair Cosmic Synergy & Lo Shu Will Plane",
            "Solar Gayatri & Authority Yantra Consecration",
            "5-Year Professional Career Dasha Radar"
        ]
    },
    "report_authority_sovereign": {
        "name": "Sovereign Identity & Name Rectification",
        "amount_inr": 5500,
        "original_price_inr": 10900,
        "amount_paise": 550000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "35-Page Executive Life Transformation",
        "features": [
            "Complete 35-Page Sovereign Executive Blueprint",
            "Professional Name Spelling Rectification for Authority",
            "Public Stature & Government Career Roadmap",
            "1-Year AI Question Credits Included"
        ]
    },
    # Domain 4: Global Horizon & Relocation (Harmonic Root 5/6 · Global Passage)
    "report_relocation_tripwire": {
        "name": "International Visa & Travel Unblocker",
        "amount_inr": 149,
        "original_price_inr": 410,
        "amount_paise": 14900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "2-Page Foreign Movement Timing Guide",
        "features": [
            "Favorable Visa Lodgment & Submission Windows",
            "Compass Direction Alignment for Target Countries",
            "Travel Plane Neutralization for Delays",
            "Auspicious Departure Timing"
        ]
    },
    "report_relocation_master": {
        "name": "Global Settlement Dossier",
        "amount_inr": 510,
        "original_price_inr": 1500,
        "amount_paise": 51000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "12-Page Overseas Relocation Synthesis",
        "features": [
            "Full 12-Page Master Dossier with Gold Seals",
            "Permanent Residency (PR) / Settlement Timeline",
            "Overseas Living & Relocation Vastu Vectors",
            "Annual International Opportunities Radar"
        ]
    },
    "report_relocation_sovereign": {
        "name": "Sovereign Global Migration Matrix",
        "amount_inr": 5100,
        "original_price_inr": 10500,
        "amount_paise": 510000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "35-Page Full International Living Roadmap",
        "features": [
            "Complete 35-Page Sovereign Global Migration Matrix",
            "Passport Name Spelling & International Vibration",
            "Multi-Country Synastry & Relocation Mapping",
            "1-Year AI Question Credits Included"
        ]
    },
    # Domain 5: Higher Calling & Mentorship (Harmonic Root 3 · Higher Wisdom)
    "report_dharma_tripwire": {
        "name": "Dharma Compass & Purpose Unblocker",
        "amount_inr": 120,
        "original_price_inr": 390,
        "amount_paise": 12000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "2-Page Life Calling & Clarity Guide",
        "features": [
            "Life Purpose & Core Natal Mission Alignment",
            "Spiritual Blockage & Confusion Neutralization",
            "Thursday Wisdom Sadhana & Yellow Attunement",
            "Wisdom Sanctuary & Meditation Orientation"
        ]
    },
    "report_dharma_master": {
        "name": "Sovereign Wisdom Dossier",
        "amount_inr": 570,
        "original_price_inr": 1200,
        "amount_paise": 57000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "12-Page Soul Path & Sadhana Synthesis",
        "features": [
            "Full 12-Page Master Dossier with Gold Seals",
            "Thought & Spiritual Plane Lo Shu Integration",
            "Wisdom Beej Mantra & Consecrated Yantra Guide",
            "Ancestral Karma (Pitra) Balancing Protocol"
        ]
    },
    "report_dharma_sovereign": {
        "name": "Karmic Destiny & Life Blueprint",
        "amount_inr": 4800,
        "original_price_inr": 12000,
        "amount_paise": 480000,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "description": "35-Page Full Spiritual Transformation",
        "features": [
            "Complete 35-Page Karmic Destiny Blueprint",
            "Spiritual Name Vibration & Acoustic Resonance",
            "Multi-Decade Soul Evolution & Dharma Timeline",
            "1-Year AI Question Credits Included"
        ]
    },

    # ── 7. SCREENSHOT-BASED REPORT CATALOGUE (18 PRODUCTS) ───────────────────
    # Group: Love and Marriage (Pricing Personality: 6)
    "report_love_style": {
        "name": "Love Style Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "💖",
        "description": "Explore your romantic expression, attachment archetype, and Venusian emotional harmony.",
        "features": [
            "Emotional & Romantic Frequency Analysis",
            "Venusian & Lunar Polarity Breakdown",
            "Love Attachment Style & Communication Needs",
            "Harmonizing Color & Crystal Recommendations"
        ]
    },
    "report_marriage": {
        "name": "Marriage Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "💍",
        "description": "Comprehensive marital alignment, timing windows, and domestic harmony blueprint.",
        "features": [
            "Marital Readiness & 7th House Axis Analysis",
            "Auspicious Marriage Timing & Dasha Windows",
            "Sacred Union Harmony & Long-term Bonding",
            "Marital Remedial Protocols (Vedic & Lo Shu)"
        ]
    },
    "report_ideal_partner": {
        "name": "Ideal Partner Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "🏹",
        "description": "Identify the psychological archetype, planetary ruler, and compatible vibration of your ideal partner.",
        "features": [
            "Soulmate Vibration & Karaka Significations",
            "Complementary Number Profiles (Driver & Conductor)",
            "Key Interpersonal Dynamics & Shared Values",
            "Red Flag Frequencies & Alignment Guidance"
        ]
    },
    "report_love_or_arrange": {
        "name": "Love or Arrange Exploration Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "⚖️",
        "description": "Evaluate classical indicators of self-chosen love vs traditional arranged marriage dynamics.",
        "features": [
            "5th vs 7th/9th House Influence Comparison",
            "Planetary Indicators for Self-Chosen vs Family Alliances",
            "Family Acceptance Potential & Parental Blessing Indicators",
            "Diplomatic Guidance for Navigating Marital Choices"
        ]
    },
    "report_spouse": {
        "name": "Spouse Personality & Life Alignment Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "👑",
        "description": "Detailed portrait of your future spouse's temperament, career inclination, and shared destiny.",
        "features": [
            "Spouse Temperament & Behavioral Archetype",
            "Likely Professional Domain & Social Standing",
            "Post-Marriage Fortune & Wealth Activation",
            "Harmonious Daily Habits & Relationship Care"
        ]
    },
    "report_in_laws": {
        "name": "In-Laws & Family Harmony Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Love and Marriage",
        "pricing_personality": 6,
        "icon": "🏡",
        "description": "Navigate relationships with extended family, in-laws, and domestic authority figures peacefully.",
        "features": [
            "In-Law Astrological House Influences (9th/10th from 7th)",
            "Potential Communication Friction Points & Solutions",
            "Vedic Vastu Directions for Family Harmony",
            "Boundary Setting & Diplomatic Grace Protocols"
        ]
    },

    # Group: Money (Pricing Personality: 1 or 6)
    "report_billionaire_potential": {
        "name": "Billionaire Potential & Wealth Blueprint",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Money",
        "pricing_personality": 1,
        "icon": "💰",
        "description": "High-tier sovereign wealth architecture, multi-generational accumulation, and Dhana Yoga indicators.",
        "features": [
            "Dhana Yoga & Lakshmi Yoga Conjunction Audit",
            "Lo Shu Prosperity Plane (4-5-6) Golden Flow Evaluation",
            "High-Stakes Capital Deployment Windows",
            "Wealth Retention & Institutional Compounding Strategy"
        ]
    },
    "report_wealth": {
        "name": "Wealth & Abundance Report",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Money",
        "pricing_personality": 6,
        "icon": "💎",
        "description": "Practical financial liquidity, debt neutralization, and money vibration calibration.",
        "features": [
            "Personal Money Number & Cashflow Frequency",
            "Wealth Blockers & Leakage Identification",
            "Optimal Bank Account & Invoice Number Vibration",
            "Kuber Yantra & Directional Vastu Protocols"
        ]
    },

    # Group: Work (Pricing Personality: 1 or 5)
    "report_career": {
        "name": "Career Blueprint & Leadership Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 1,
        "icon": "🎯",
        "description": "Comprehensive career trajectory, executive promotion timing, and corporate growth roadmap.",
        "features": [
            "10th House Institutional Authority Analysis",
            "Executive Leadership & Management Style",
            "Promotion & Band Advancement Timing Windows",
            "Workplace Friction Mitigation Strategies"
        ]
    },
    "report_business": {
        "name": "Business Alignment & Commercial Direction Report",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 1,
        "icon": "🏢",
        "description": "Evaluate commercial venture viability, market timing, founder archetype, and scalability.",
        "features": [
            "Founder Archetype & Industry Domain Synergy",
            "Auspicious Venture Incorporation Windows",
            "Partnership Synastry & Capital Risk Assessment",
            "Commercial Brand Name Numerical Balancing"
        ]
    },
    "report_job_or_business": {
        "name": "Job or Business Decision Dossier",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 5,
        "icon": "🔄",
        "description": "Resolve the foundational dilemma: executive employment stability vs independent enterprise freedom.",
        "features": [
            "Service (6th House) vs Enterprise (7th/10th House) Balance",
            "Autonomy Readiness Score & Risk Tolerance Audit",
            "Optimal Transition Timing & Phased Pivoting Protocol",
            "Moonlighting & Side-Venture Safety Guidelines"
        ]
    },
    "report_govt_job": {
        "name": "Govt Job & Administrative Exam Alignment Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 1,
        "icon": "🏛️",
        "description": "Assess Sun/Surya and Saturn authority indicators for public sector, civil service, and competitive exams.",
        "features": [
            "Sovereign Authority & Government Favor Indicators",
            "Competitive Examination Focus & Success Windows",
            "Judiciary, Defense, and Administrative Aptitude",
            "Sun Arghya & Gayatri Remedial Activation"
        ]
    },
    "report_first_job": {
        "name": "First Job & Graduate Career Starter Report",
        "amount_inr": 199,
        "original_price_inr": 399,
        "amount_paise": 19900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 1,
        "icon": "🚀",
        "description": "Essential guidance for students, fresh graduates, and entry-level professionals embarking on work life.",
        "features": [
            "Natural Workplace Superpowers & First-Job Roles",
            "Interview Presentation & Resume Energy Alignment",
            "Overcoming Early Career Imposter Syndrome",
            "Auspicious Joining Dates & Morning Centering Habits"
        ]
    },
    "report_job_search": {
        "name": "Job Search & Career Transition Strategy Report",
        "amount_inr": 199,
        "original_price_inr": 399,
        "amount_paise": 19900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Work",
        "pricing_personality": 5,
        "icon": "🔍",
        "description": "Actionable tactical guide to accelerate pending interview callbacks, headhunter outreach, and offers.",
        "features": [
            "Active Dasha Timing for Applications & Interviews",
            "Resume Keyword Energy & Calling Signature",
            "Interview Day Planetary Hora Selection",
            "Stuck Momentum Grounding Rituals"
        ]
    },

    # Group: Self and Growth (Pricing Personality: 1 or 3)
    "report_intelligence": {
        "name": "Intelligence & Cognitive Mastery Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Self and Growth",
        "pricing_personality": 3,
        "icon": "🧠",
        "description": "Discover your unique intellectual wiring: strategic, analytical, creative, or intuitive cognition.",
        "features": [
            "Cognitive Modality & Mental Processing Speed",
            "Mercury-Jupiter Intellect Conjunction Dynamics",
            "Optimal Learning Environments & Study Hours",
            "Memory Enhancement & Mental Fatigue Clearing"
        ]
    },
    "report_life_guidance": {
        "name": "Life Guidance & Sovereign Purpose Dossier",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Self and Growth",
        "pricing_personality": 1,
        "icon": "🧭",
        "description": "Clear life direction, moral compass, and soul lesson navigation across your current decade.",
        "features": [
            "Soul Calling & Core Ethical Mission Blueprint",
            "Karmic Lessons & Repetitive Life Patterns",
            "Navigating Major Mid-Life & Saturnian Milestones",
            "Daily Centering & Spiritual Grounding Practices"
        ]
    },
    "report_personality": {
        "name": "Personality Archetype & Soul Expression Report",
        "amount_inr": 199,
        "original_price_inr": 399,
        "amount_paise": 19900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Self and Growth",
        "pricing_personality": 3,
        "icon": "✨",
        "description": "Deep dive into your outer projection, inner temperament, and unconscious psychological drivers.",
        "features": [
            "Driver/Conductor Behavioral Polarity Analysis",
            "Public Aura vs Private Self Dynamics",
            "Natural Charisma & Persuasion Strengths",
            "Blindspot Neutralization & Personal Poise"
        ]
    },
    "report_education": {
        "name": "Education & Academic Mastery Report",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "Instant Download",
        "questions_count": 0,
        "has_remedies": True,
        "category": "report",
        "category_group": "Self and Growth",
        "pricing_personality": 3,
        "icon": "🎓",
        "description": "Academic stream selection, higher education timing, exam focus, and foreign study prospects.",
        "features": [
            "Auspicious Academic Disciplines & University Fields",
            "Foreign Education & Overseas Degree Prospects",
            "Exam Pacing & Retention Enhancement",
            "Saraswati Beej Mantra & Study Space Vastu"
        ]
    },

    # ── 8. REPORT BUNDLES (8 VALUE SETS) ──────────────────────────────────────
    "bundle_love_compatibility": {
        "name": "Love & Compatibility Set",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 6,
        "included_reports": ["report_love_style", "report_ideal_partner", "report_marriage"],
        "description": "Complete romantic journey package: Love Style, Ideal Partner profile, and Marriage timing blueprint.",
        "features": [
            "3 Comprehensive PDF Reports (Love Style, Ideal Partner, Marriage)",
            "Combined Venusian & Spousal Synastry Breakdown",
            "Save ₹500 off the bundle list price",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_marriage_family": {
        "name": "Marriage & Family Harmony Set",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 6,
        "included_reports": ["report_marriage", "report_spouse", "report_in_laws"],
        "description": "Total marital and domestic serenity package: Marriage readiness, Spouse personality, and In-laws harmony.",
        "features": [
            "3 Comprehensive PDF Reports (Marriage, Spouse, In-Laws)",
            "Extended Family Vastu & Communication Protocol",
            "Save ₹500 off the bundle list price",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_career_starter": {
        "name": "Career Starter Set",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 1,
        "included_reports": ["report_first_job", "report_job_search", "report_career"],
        "description": "Essential stepping stones for early career professionals: First Job, Job Search tactics, and Career blueprint.",
        "features": [
            "3 Practical PDF Reports (First Job, Job Search, Career)",
            "Interview Timing & Resume Calibration Guides",
            "Save ₹600 (46% off) compared to bundle list price",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_career_decision": {
        "name": "Career Decision Set",
        "amount_inr": 1999,
        "original_price_inr": 2499,
        "amount_paise": 199900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 1,
        "included_reports": ["report_career", "report_business", "report_job_or_business"],
        "description": "Definitive career crossroads package: Career leadership, Business venture feasibility, and Job vs Business.",
        "features": [
            "3 Comprehensive PDF Reports (Career, Business, Job or Business)",
            "Executive Transition & Corporate Autonomy Roadmap",
            "Save ₹500 off the bundle list price (Save ₹598 over individual offers)",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_money_wealth": {
        "name": "Money & Wealth Set",
        "amount_inr": 1999,
        "original_price_inr": 2499,
        "amount_paise": 199900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 6,
        "included_reports": ["report_wealth", "report_billionaire_potential"],
        "description": "Total financial mastery package: Wealth cashflow management and Sovereign Billionaire Potential blueprint.",
        "features": [
            "2 Elite Financial PDF Reports (Wealth, Billionaire Potential)",
            "Dhana Yoga & Cashflow Leakage Remediation",
            "Save ₹500 off bundle list (Save ₹199 over individual offers)",
            "Lifetime access to both reports"
        ]
    },
    "bundle_self_discovery": {
        "name": "Self-Discovery Set",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 3,
        "included_reports": ["report_personality", "report_intelligence", "report_life_guidance"],
        "description": "Profound inner alignment package: Personality archetype, Cognitive intelligence, and Sovereign life guidance.",
        "features": [
            "3 In-Depth Personal PDF Reports (Personality, Intelligence, Life Guidance)",
            "Cognitive Wiring & Soul Purpose Alignment",
            "Save ₹500 off the bundle list price",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_learning_growth": {
        "name": "Learning & Growth Set",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "Instant Bundle Access",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 3,
        "included_reports": ["report_education", "report_intelligence", "report_personality"],
        "description": "Intellectual mastery package: Academic achievement, Intellectual aptitude, and Personality strengths.",
        "features": [
            "3 Focused Educational PDF Reports (Education, Intelligence, Personality)",
            "Study Vastu & Academic Timing Calendars",
            "Save ₹500 off the bundle list price",
            "Lifetime access to all 3 reports"
        ]
    },
    "bundle_complete_personal_insight": {
        "name": "Complete Personal Insight Set",
        "amount_inr": 2499,
        "original_price_inr": 3999,
        "amount_paise": 249900,
        "period": "All-Access Dossier Suite",
        "questions_count": 0,
        "has_remedies": True,
        "category": "bundle",
        "pricing_personality": 3,
        "included_reports": [
            "report_love_style", "report_marriage", "report_ideal_partner", "report_love_or_arrange",
            "report_spouse", "report_in_laws", "report_billionaire_potential", "report_wealth",
            "report_career", "report_business", "report_job_or_business", "report_govt_job",
            "report_first_job", "report_job_search", "report_intelligence", "report_life_guidance",
            "report_personality", "report_education"
        ],
        "description": "All-inclusive master suite: Complete lifetime access to all 18 screenshot-based Numeros Vision reports.",
        "features": [
            "All 18 Numeros Vision Personalized PDF Reports Included",
            "Love, Wealth, Work, and Self Growth full libraries",
            "Save ₹1,500 off bundle list (Huge savings over individual purchases)",
            "Lifetime access to all existing and upgraded editions"
        ]
    },

    # ── 9. CHARM AI CONVERSATIONAL PACKAGES (6 TIERS) ─────────────────────────
    "charm_quick_insight": {
        "name": "Charm AI — Quick Insight",
        "amount_inr": 199,
        "original_price_inr": 399,
        "amount_paise": 19900,
        "period": "1 Focused Question",
        "questions_count": 1,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 1,
        "scope": "One clearly defined focused question and concise master consultation answer.",
        "description": "One targeted question prediction with instant grounded clarity and unblocking next steps.",
        "features": [
            "1 Focused Charm AI Master Consultation Turn",
            "Empathetic Golden Heart dialogue & diagnosis",
            "Grounding unblocking practical actions",
            "Valid across Career, Love, Wealth or Health"
        ]
    },
    "charm_focused_reading": {
        "name": "Charm AI — Focused Reading",
        "amount_inr": 399,
        "original_price_inr": 699,
        "amount_paise": 39900,
        "period": "4 Questions Allowance",
        "questions_count": 4,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 3,
        "scope": "One topic with a defined follow-up allowance and structured summary.",
        "description": "Deep-dive inquiry into a single life challenge with up to 3 follow-up clarifying questions.",
        "features": [
            "4 Dedicated Charm AI Consultation Turns",
            "In-depth topic exploration with follow-up allowance",
            "Structured summary & timing window breakdown",
            "Custom 7-Layer safe lifestyle remedies"
        ]
    },
    "charm_consensus_reading": {
        "name": "Charm AI — Consensus Reading",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "8 Questions + Cross-Verification",
        "questions_count": 8,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 5,
        "scope": "One topic evaluated across eligible, enabled and validated traditions.",
        "description": "Rigorous cross-verification comparing Numerology Dasha against KP, Vedic Parashari, and BNN.",
        "features": [
            "8 In-depth Charm AI Consultation Turns",
            "Deterministic multi-system consensus evaluation",
            "Citations from verified Numeros Vision classical corpus",
            "Strict status badge (CORROBORATED / CONFLICTED / ONLY)"
        ]
    },
    "charm_personal_blueprint": {
        "name": "Charm AI — Personal Blueprint",
        "amount_inr": 1499,
        "original_price_inr": 1999,
        "amount_paise": 149900,
        "period": "20 Questions Allowance",
        "questions_count": 20,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 1,
        "scope": "Multi-topic analysis using only actually supported features.",
        "description": "Full life-aspect exploration spanning career pivots, marital timing, and financial security.",
        "features": [
            "20 Comprehensive Charm AI Consultation Turns",
            "Multi-topic coverage (Career, Wealth, Relationships, Health)",
            "Annual Personal Year transit and hora timing radar",
            "Downloadable summary transcript of full consultation"
        ]
    },
    "charm_family_compatibility": {
        "name": "Charm AI — Family Compatibility",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "8 Questions (Multi-Profile)",
        "questions_count": 8,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 6,
        "scope": "Compatibility themes for user-supplied profiles with appropriate consent.",
        "description": "Interactive dual-profile synastry consultation exploring partner, family, or business synergy.",
        "features": [
            "8 Dual-Profile Charm AI Consultation Turns",
            "Driver/Conductor polarity and shared Lo Shu plane audit",
            "Interpersonal friction mitigation and communication advice",
            "Complies strictly with statutory DPDP 2023 consent"
        ]
    },
    "charm_career_business_direction": {
        "name": "Charm AI — Career & Business Direction",
        "amount_inr": 699,
        "original_price_inr": 1299,
        "amount_paise": 69900,
        "period": "8 Focused Career Turns",
        "questions_count": 8,
        "has_remedies": True,
        "category": "charm_package",
        "pricing_personality": 1,
        "scope": "Career/business exploration and practical next-step prompts.",
        "description": "Dedicated corporate and commercial guidance for job transitions, appraisal timing, or founder pivots.",
        "features": [
            "8 Strategic Career & Business Turns",
            "Acute execution window mapping (Pratyantardasha)",
            "3-point practical outreach & workspace grounding actions",
            "Zero ungrounded speculation or commercial guarantees"
        ]
    },
}

# ── Persistent verified-payment session store ──────────────────────────────
_verified_payments: dict = {}

# Cloud-Native Distributed Session Cache (Redis)
REDIS_URL = os.getenv("REDIS_URL")
_redis_client = None
if REDIS_URL:
    try:
        import redis
        _redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    except Exception:
        _redis_client = None

def _load_sessions():
    """Load persisted verified sessions from disk on startup."""
    global _verified_payments
    try:
        if os.path.exists(SESSIONS_FILE):
            with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    _verified_payments.update(data)
    except Exception:
        pass

def _save_sessions(session_token: Optional[str] = None):
    """Persist verified sessions to disk atomically and sync to Redis if available."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(SESSIONS_FILE, "w", encoding="utf-8") as f:
            json.dump(_verified_payments, f, indent=2)
    except Exception:
        pass

    if _redis_client and session_token and session_token in _verified_payments:
        try:
            _redis_client.set(
                f"session:{session_token}",
                json.dumps(_verified_payments[session_token]),
                ex=86400 * 30  # 30-day session TTL
            )
        except Exception:
            pass

# Initialize on module import
_load_sessions()

def get_session_info(token: str) -> Optional[dict]:
    """Retrieve session info for a given premium/subscription token."""
    if not token:
        return None
    # Universal Test & Staging access for full workable testing of all calculators and packages
    if token in ("test_master_pass", "test_token", "demo_mode", "admin_test") or token.startswith("test_"):
        is_prod = os.getenv("ENVIRONMENT", "development").lower() == "production"
        allow_test = os.getenv("ALLOW_TEST_TOKENS", "true" if not is_prod else "false").lower() == "true"
        if is_prod and not allow_test:
            # In strict live production, reject hardcoded test tokens to prevent outer bypass
            return None

        return {
            "token": token,
            "plan": "complete_report",
            "plan_name": "Complete Reports & Remedies (Test Access)",
            "questions_remaining": 9999,
            "has_remedies": True,
            "has_btr": True,
            "verified_at": int(time.time()),
            "status": "active"
        }
    if _redis_client:
        try:
            cached = _redis_client.get(f"session:{token}")
            if cached:
                return json.loads(cached)
        except Exception:
            pass
    return _verified_payments.get(token)

def consume_question(token: str) -> bool:
    """Consume 1 question from the quota if available and persist."""
    session = get_session_info(token)
    if not session:
        return False
    # If unlimited (complete plan has 9999)
    if session.get("questions_remaining", 0) > 0:
        session["questions_remaining"] -= 1
        _verified_payments[token] = session
        _save_sessions(token)
        return True
    return False

def record_question_history(token: str, question: str, answer_summary: str = "", topic: str = ""):
    """Record question and answer into session memory for multi-turn conversational context."""
    session = get_session_info(token)
    if not session:
        return
    if "question_history" not in session:
        session["question_history"] = []
    session["question_history"].append({
        "question": question,
        "topic": topic,
        "answer_summary": answer_summary[:300] if answer_summary else "",
        "timestamp": int(time.time())
    })
    _verified_payments[token] = session
    _save_sessions(token)

# ── Request models ─────────────────────────────────────────────────────────
class CreateOrderRequest(BaseModel):
    plan: Optional[str] = None
    plan_id: Optional[str] = None
    name: Optional[str] = ""
    customer_name: Optional[str] = ""
    email: Optional[str] = ""
    customer_email: Optional[str] = ""
    mobile: Optional[str] = ""
    customer_phone: Optional[str] = ""
    amount: Optional[int] = None
    currency: Optional[str] = "INR"

class VerifyPaymentRequest(BaseModel):
    razorpay_order_id:   str
    razorpay_payment_id: str
    razorpay_signature:  str
    plan: Optional[str] = None
    plan_id: Optional[str] = None
    email: Optional[str] = ""

class AlignmentGapRequest(BaseModel):
    driver: Optional[int] = 1
    conductor: Optional[int] = 1
    loshu_counts: Optional[Dict[str, int]] = None
    missing_numbers: Optional[List[int]] = None
    name_number: Optional[int] = None
    personal_year: Optional[int] = None
    active_dasha: Optional[str] = None
    current_plan: Optional[str] = "free"
    credits_remaining: Optional[int] = 0
    token: Optional[str] = None

class FunnelNextStepRequest(BaseModel):
    product_id: Optional[str] = "birth_number"
    calculation_completed: Optional[bool] = False
    free_result_available: Optional[bool] = False
    token: Optional[str] = None
    opted_out: Optional[bool] = False

class PriceValidationRequest(BaseModel):
    reference: Optional[int] = None
    offer: Optional[int] = None
    amount: Optional[int] = None

class FunnelEventRequest(BaseModel):
    event: str
    product_id: Optional[str] = None
    stage: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


PLAN_COVERAGE_HIERARCHY = {
    "complete_report": {
        "complete_report", "complete", "report_master", "report_essential", "report_divine",
        "starter_5q", "starter", "growth_10q", "growth", "free", "discovery"
    },
    "report_divine": {
        "report_divine", "report_master", "report_essential", "complete_report", "free", "discovery"
    },
    "report_master": {
        "report_master", "report_essential", "free", "discovery"
    },
    "report_essential": {
        "report_essential", "free", "discovery"
    },
    "growth_10q": {
        "growth_10q", "growth", "starter_5q", "starter", "free", "discovery"
    },
    "starter_5q": {
        "starter_5q", "starter", "free", "discovery"
    },
    "ai_power_35q": {
        "ai_power_35q", "ai_growth_15q", "ai_starter_5q", "free", "discovery"
    },
    "ai_growth_15q": {
        "ai_growth_15q", "ai_starter_5q", "free", "discovery"
    },
    "ai_starter_5q": {
        "ai_starter_5q", "free", "discovery"
    }
}


def check_report_access(
    requested_tier: str,
    token: Optional[str] = None,
    user_id: Optional[str] = None,
    request: Optional[Request] = None
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """
    Gatekeeper for report tiers (Rules 2 & 3):
    1. Free tier is always accessible.
    2. Staging replica mode bypasses paywall for complete QA/QC testing.
    3. Paid tiers check active session token or registered user profile entitlements.
    4. If denied, generates personalized gap analysis and 'Anviel Every Charm' CTA.
    """
    clean_tier = requested_tier.lower().strip()
    if clean_tier in ("free", "discovery"):
        return True, "free_tier", None

    # Check Staging Replica Mode bypass
    if request:
        headers = dict(request.headers)
        params = dict(request.query_params)
        if is_staging_bypass_authorized(headers, params, token):
            return True, "staging_replica_bypass", {"staging_mode": True}

    # Check Verified Payment Session
    session = get_session_info(token) if token else None
    if session:
        session_plan = session.get("plan", "")
        covered = PLAN_COVERAGE_HIERARCHY.get(session_plan, {session_plan})
        if clean_tier in covered or session_plan == clean_tier:
            return True, "session_authorized", session

    # Check Registered User Account Entitlements
    user = None
    if user_id:
        user = get_user_account_by_identifier(user_id)
    elif token and token in _ACTIVE_SESSIONS:
        auth_sess = _ACTIVE_SESSIONS[token]
        uid = auth_sess.get("user_id")
        user = _USER_ACCOUNTS.get(uid) if uid else None

    if user:
        unlocked = user.get("unlocked_reports", [])
        if clean_tier in unlocked:
            return True, "user_unlocked_report", user
        for plan in user.get("purchased_plans", []):
            covered = PLAN_COVERAGE_HIERARCHY.get(plan, {plan})
            if clean_tier in covered:
                return True, "user_purchased_plan_covered", user

    # Access Denied: User has not purchased this report tier
    d = user.get("driver_mulank", 1) if user else 1
    c = user.get("conductor_bhagyank", 1) if user else 1
    loshu = user.get("loshu_counts", {}) if user else {}
    missing = user.get("missing_numbers", []) if user else []

    gap_data = analyze_user_alignment_and_gaps(
        driver=d,
        conductor=c,
        loshu_counts=loshu,
        missing_numbers=missing,
        current_plan="free"
    )

    return False, "PAYMENT_REQUIRED", gap_data


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.get("/plans")
def get_plans():
    """Return public pricing catalogue — no auth required."""
    # Exclude internal backwards-compatibility aliases
    excluded_aliases = {"starter", "growth", "complete", "vip_consult"}
    
    formatted_plans = {}
    for k, v in PLANS.items():
        if k in excluded_aliases:
            continue
        orig = v.get("original_price_inr", v["amount_inr"])
        offer = v["amount_inr"]
        formatted_plans[k] = {
            "name":               v["name"],
            "amount_inr":         offer,
            "original_price_inr": orig,
            "amount_paise":       v.get("amount_paise", offer * 100),
            "period":             v["period"],
            "questions_count":    v.get("questions_count", 0),
            "has_remedies":       v.get("has_remedies", False),
            "category":           v.get("category", "consultation"),
            "category_group":     v.get("category_group", ""),
            "pricing_personality": v.get("pricing_personality"),
            "list_price_root":    digit_root(orig) if orig > 0 else 0,
            "offer_price_root":   digit_root(offer) if offer > 0 else 0,
            "included_reports":   v.get("included_reports", []),
            "icon":               v.get("icon", "📜"),
            "scope":              v.get("scope", ""),
            "savings_inr":        orig - offer if orig > offer else 0,
            "discount_percent":   round(((orig - offer) / orig) * 100) if orig > offer else 0,
            "description":        v.get("description", ""),
            "features":           v.get("features", []),
        }

    return {
        "status": "success",
        "success": True,
        "plans": formatted_plans,
        "currency": "INR",
        "razorpay_key": RAZORPAY_KEY_ID,   # public key — safe to expose to frontend
    }


@router.post("/alignment-gap-analysis")
async def get_alignment_gap_analysis(req: AlignmentGapRequest, request: Request):
    """
    Rule 1 & 2: Deterministic Alignment & Gap Analysis Endpoint.
    Analyzes driver-conductor alignment, Lo Shu missing planes (Golden Plane 4-5-6),
    and generates personalized conversion hooks with 'Anviel Every Charm' CTAs.
    """
    driver = req.driver or 1
    conductor = req.conductor or 1
    loshu_counts = req.loshu_counts or {}
    missing_numbers = req.missing_numbers or []
    current_plan = req.current_plan or "free"
    credits_remaining = req.credits_remaining or 0

    token = req.token or request.cookies.get("nv_user_session")
    if token and token in _ACTIVE_SESSIONS:
        sess = _ACTIVE_SESSIONS[token]
        user = _USER_ACCOUNTS.get(sess.get("user_id"))
        if user:
            driver = user.get("driver_mulank", driver)
            conductor = user.get("conductor_bhagyank", conductor)
            loshu_counts = user.get("loshu_counts", loshu_counts)
            missing_numbers = user.get("missing_numbers", missing_numbers)
            credits_remaining = user.get("charm_credits_remaining", credits_remaining)
            purchased = user.get("purchased_plans", [])
            current_plan = purchased[-1] if purchased else "free"

    analysis = analyze_user_alignment_and_gaps(
        driver=driver,
        conductor=conductor,
        loshu_counts=loshu_counts,
        missing_numbers=missing_numbers,
        name_number=req.name_number,
        personal_year=req.personal_year,
        active_dasha=req.active_dasha,
        current_plan=current_plan,
        credits_remaining=credits_remaining
    )
    return analysis


@router.post("/create-order")
async def create_order(req: CreateOrderRequest):
    """
    Create a Razorpay order and return the order_id + public key to the frontend.
    The frontend then opens the Razorpay checkout modal using these details.
    """
    plan_key = req.plan or req.plan_id or "starter_5q"
    if plan_key not in PLANS:
        raise HTTPException(status_code=400, detail=f"Unknown plan: {plan_key}")

    plan = PLANS[plan_key]
    customer_name = req.name or req.customer_name or ""
    customer_email = req.email or req.customer_email or ""
    customer_mobile = req.mobile or req.customer_phone or ""

    # ── If Razorpay SDK is installed, use it ──────────────────────────────
    try:
        import razorpay  # pip install razorpay
        client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
        order = client.order.create({
            "amount":   plan["amount_paise"],
            "currency": "INR",
            "receipt":  f"nv_{plan_key}_{int(time.time())}",
            "notes": {
                "plan":   plan_key,
                "name":   customer_name,
                "email":  customer_email,
                "mobile": customer_mobile,
            }
        })
        order_id = order["id"]
    except Exception:
        # ── Fallback: return a mock order_id for local dev without razorpay SDK or dummy keys ──
        order_id = f"order_MOCK_{plan_key}_{int(time.time())}"

    return {
        "order_id":    order_id,
        "amount":      plan["amount_paise"],
        "amount_inr":  plan["amount_inr"],
        "currency":    "INR",
        "plan":        plan_key,
        "plan_name":   plan["name"],
        "key":         RAZORPAY_KEY_ID,
        "name":        customer_name,
        "email":       customer_email,
        "mobile":      customer_mobile,
        "description": plan["description"],
    }


@router.post("/verify")
async def verify_payment(req: VerifyPaymentRequest):
    """
    Verify Razorpay payment signature on the server side.
    Called by the frontend after razorpay.on('payment.success').
    Returns a session token that unlocks premium features.
    """
    is_mock = (
        req.razorpay_order_id.startswith("order_MOCK_") or
        req.razorpay_payment_id.startswith("pay_MOCK_") or
        RAZORPAY_KEY_SECRET in ("REPLACE_ME_SECRET", "REPLACE_WITH_ACTUAL_RAZORPAY_KEY_SECRET")
    )

    if not is_mock:
        # ── HMAC-SHA256 signature verification ────────────────────────────────
        expected_signature = hmac.new(
            RAZORPAY_KEY_SECRET.encode(),
            f"{req.razorpay_order_id}|{req.razorpay_payment_id}".encode(),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_signature, req.razorpay_signature):
            raise HTTPException(status_code=400, detail="Payment verification failed — invalid signature.")

    # ── Payment verified — store and return premium token ─────────────────
    session_token = hashlib.sha256(
        f"{req.razorpay_payment_id}{RAZORPAY_KEY_SECRET}".encode()
    ).hexdigest()[:32]

    plan_key = req.plan or req.plan_id or "starter_5q"
    plan_info = PLANS.get(plan_key, {})
    q_count = plan_info.get("questions_count", 5)

    _verified_payments[session_token] = {
        "plan":                plan_key,
        "plan_name":           plan_info.get("name", "Charm AI"),
        "payment_id":          req.razorpay_payment_id,
        "order_id":            req.razorpay_order_id,
        "email":               req.email or "",
        "questions_count":     q_count,
        "questions_remaining": q_count,
        "has_remedies":        plan_info.get("has_remedies", False),
        "verified_at":         int(time.time()),
    }
    _save_sessions()

    # Synchronize entitlements with registered user account if present
    if req.email:
        # Unlock all included reports if plan is a bundle
        if plan_key.startswith("bundle_"):
            for inc_rep in plan_info.get("included_reports", []):
                update_user_entitlements(
                    email_or_user_id=req.email,
                    plan_id=inc_rep,
                    credits_to_add=0,
                    unlocked_report=inc_rep
                )
        update_user_entitlements(
            email_or_user_id=req.email,
            plan_id=plan_key,
            credits_to_add=q_count if q_count < 9999 else 9999,
            unlocked_report=plan_key if (plan_key.startswith("report_") or plan_key.startswith("bundle_") or plan_key in ["complete_report", "starter_5q", "growth_10q"]) else None
        )

    # Persist to bookings log
    _persist_payment(req, session_token)

    return {
        "status":              "verified",
        "premium_token":       session_token,
        "plan":                plan_key,
        "plan_name":           plan_info.get("name", "Charm AI"),
        "questions_remaining": q_count,
        "has_remedies":        plan_info.get("has_remedies", False),
        "amount_inr":          plan_info.get("amount_inr", 95),
        "message":             f"Payment verified. Your {plan_info.get('name', 'Charm AI')} is now active.",
    }


@router.get("/status/{session_token}")
def check_status(session_token: str):
    """Check if a session token corresponds to a verified premium payment."""
    record = _verified_payments.get(session_token)
    if not record:
        return {"active": False}
    return {
        "active": True,
        "plan":   record["plan"],
        "email":  record.get("email", ""),
        "questions_remaining": record.get("questions_remaining", 0),
        "has_remedies": record.get("has_remedies", False),
    }


@router.post("/webhook")
async def razorpay_webhook(request: Request):
    """
    Razorpay Server-to-Server Webhook Handler.
    Handles 'payment.captured' and 'order.paid' events.
    Verifies X-Razorpay-Signature using RAZORPAY_WEBHOOK_SECRET.
    """
    raw_body = await request.body()
    signature = request.headers.get("X-Razorpay-Signature", "")

    # Verify signature if secret is configured and not default placeholder
    if RAZORPAY_WEBHOOK_SECRET not in ("REPLACE_ME_SECRET", "REPLACE_WITH_ACTUAL_RAZORPAY_KEY_SECRET"):
        expected_sig = hmac.new(
            RAZORPAY_WEBHOOK_SECRET.encode(),
            raw_body,
            hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(expected_sig, signature):
            raise HTTPException(status_code=400, detail="Invalid webhook signature")

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event = payload.get("event", "")

    if event in ("payment.captured", "order.paid"):
        payment_entity = payload.get("payload", {}).get("payment", {}).get("entity", {})
        order_entity = payload.get("payload", {}).get("order", {}).get("entity", {})

        payment_id = payment_entity.get("id") or f"pay_wh_{int(time.time())}"
        order_id = payment_entity.get("order_id") or order_entity.get("id") or f"order_wh_{int(time.time())}"
        notes = payment_entity.get("notes") or order_entity.get("notes") or {}
        plan_id = notes.get("plan", "starter_5q")
        email = notes.get("email", "")

        # Provision session token
        session_token = hashlib.sha256(
            f"{payment_id}{RAZORPAY_KEY_SECRET}".encode()
        ).hexdigest()[:32]

        plan_info = PLANS.get(plan_id, {})
        q_count = plan_info.get("questions_count", 5)

        _verified_payments[session_token] = {
            "plan":                plan_id,
            "plan_name":           plan_info.get("name", "Charm AI"),
            "payment_id":          payment_id,
            "order_id":            order_id,
            "email":               email,
            "questions_count":     q_count,
            "questions_remaining": q_count,
            "has_remedies":        plan_info.get("has_remedies", False),
            "verified_at":         int(time.time()),
            "source":              "webhook",
        }
        _save_sessions()

        if email:
            if plan_id.startswith("bundle_"):
                for inc_rep in plan_info.get("included_reports", []):
                    update_user_entitlements(
                        email_or_user_id=email,
                        plan_id=inc_rep,
                        credits_to_add=0,
                        unlocked_report=inc_rep
                    )
            update_user_entitlements(
                email_or_user_id=email,
                plan_id=plan_id,
                credits_to_add=q_count if q_count < 9999 else 9999,
                unlocked_report=plan_id if (plan_id.startswith("report_") or plan_id.startswith("bundle_") or plan_id in ["complete_report", "starter_5q", "growth_10q"]) else None
            )

        # Log to data/payments.jsonl
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(os.path.join(DATA_DIR, "payments.jsonl"), "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "token": session_token,
                    "plan": plan_id,
                    "payment_id": payment_id,
                    "order_id": order_id,
                    "email": email,
                    "source": "webhook",
                    "ts": int(time.time())
                }) + "\n")
        except Exception:
            pass

        return {
            "status": "success",
            "event": event,
            "session_token": session_token,
            "plan": plan_id
        }

    return {"status": "ignored", "event": event}


# ── Funnel & Customer Journey Endpoints (v1.5.0) ──────────────────────────

@router.get("/funnel/products")
def get_funnel_products():
    """Return unified product catalogue with approved funnel hooks, deliverables and CTAs."""
    return {
        "status": "success",
        "tagline": "ANVIEL EVERY CHARM",
        "currency": "INR",
        "products": PRODUCT_FUNNEL_CATALOG
    }


@router.post("/funnel/validate-price")
def validate_funnel_price(req: PriceValidationRequest):
    """
    Validates pricing against brand digit-root policy {1, 3, 5, 6}
    and verifies that offer price is strictly less than reference price.
    """
    if req.reference is not None and req.offer is not None:
        return validate_price_pair(req.reference, req.offer)
    if req.amount is not None:
        return validate_single_price(req.amount)
    raise HTTPException(status_code=400, detail="Must provide either 'amount' or both 'reference' and 'offer'")


@router.api_route("/funnel/next-step", methods=["GET", "POST"])
async def funnel_next_step(
    request: Request,
    product_id: Optional[str] = None,
    calculation_completed: Optional[bool] = None,
    free_result_available: Optional[bool] = None,
    token: Optional[str] = None,
    opted_out: Optional[bool] = None,
):
    """
    Determines seeker's next action in the 7-stage marketing funnel.
    Supports GET query parameters and POST JSON bodies.
    Enforces opt-out precedence and prevents duplicate report sales.
    """
    if request.method == "POST":
        try:
            body = await request.json()
            if isinstance(body, dict):
                product_id = body.get("product_id", product_id)
                calculation_completed = body.get("calculation_completed", calculation_completed)
                free_result_available = body.get("free_result_available", free_result_available)
                token = body.get("token", token)
                opted_out = body.get("opted_out", opted_out)
        except Exception:
            pass

    pid = product_id or "birth_number"
    calc_done = bool(calculation_completed)
    free_res = bool(free_result_available)
    is_opted_out = bool(opted_out)

    sess_token = token or request.cookies.get("nv_user_session") or request.headers.get("x-session-token")
    
    entitlements = []
    payment_status = None
    fulfilment_status = None

    if sess_token and sess_token in _verified_payments:
        rec = _verified_payments[sess_token]
        plan = rec.get("plan", "")
        entitlements.append(plan)
        payment_status = "CONFIRMED"
        fulfilment_status = "FULFILLED"

    context = JourneyContext(
        session_token=sess_token,
        user_opted_out_of_marketing=is_opted_out,
        calculation_completed=calc_done,
        free_result_available=free_res,
        payment_status=payment_status,
        fulfilment_status=fulfilment_status,
        current_entitlements=entitlements
    )

    step = get_next_step(
        user=None,
        product_id=pid,
        journey_context=context
    )
    return step


@router.post("/funnel/event")
async def capture_funnel_event(req: FunnelEventRequest, request: Request):
    """
    Captures privacy-minimised marketing funnel events.
    Rejects sensitive PII (DOB, mobile, credit card numbers).
    """
    sess_id = req.session_id or request.cookies.get("nv_user_session") or "anon"
    success = log_funnel_event(
        event_name=req.event,
        product_id=req.product_id,
        stage=req.stage,
        session_id=sess_id,
        metadata=req.metadata
    )
    return {
        "status": "success" if success else "ignored",
        "event": req.event,
        "logged": success
    }


# ── Internal helpers ───────────────────────────────────────────────────────

def _persist_payment(req: VerifyPaymentRequest, token: str):
    """Append verified payment to bookings.jsonl log."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        record = {
            "token":      token,
            "plan":       req.plan,
            "payment_id": req.razorpay_payment_id,
            "order_id":   req.razorpay_order_id,
            "email":      req.email or "",
            "ts":         int(time.time()),
        }
        with open(os.path.join(DATA_DIR, "payments.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass  # Non-critical — don't block the user response
