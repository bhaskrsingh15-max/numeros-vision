"""
BOOKINGS API — Consultation Booking & Payment Initiation
Handles: Phone/Video session requests, payment webhook, booking confirmation
"""
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime
import hashlib, json

router = APIRouter(prefix="/api/v1/bookings", tags=["Bookings"])


class BookingRequest(BaseModel):
    name: str = Field(..., description="Client full name")
    email: str = Field(..., description="Client email address")
    phone: str = Field(..., description="WhatsApp/phone number")
    session_type: str = Field(..., description="'phone' or 'video'")
    preferred_date: str = Field(..., description="Date YYYY-MM-DD")
    preferred_time: Optional[str] = Field("", description="Preferred time slot")
    focus_area: Optional[str] = Field("", description="What to focus on")
    dob: Optional[str] = Field("", description="Date of birth DD/MM/YYYY")


class BookingResponse(BaseModel):
    status: str
    booking_id: str
    session_type: str
    amount_inr: int
    message: str
    whatsapp_link: str
    payment_note: str


PRICING = {
    "phone": {"amount": 2499, "duration": "45 minutes"},
    "video": {"amount": 3999, "duration": "60 minutes"},
    "personal": {"amount": 11400, "duration": "90 minutes"},
}

# Your WhatsApp business number (update this)
WHATSAPP_NUMBER = "919999999999"  # Replace with your actual number


@router.post("/request", response_model=BookingResponse)
def request_consultation(req: BookingRequest, background_tasks: BackgroundTasks):
    """
    Submit a consultation booking request.
    Returns booking ID, pricing, and WhatsApp confirmation link.
    """
    if req.session_type not in PRICING:
        raise HTTPException(status_code=400, detail="session_type must be 'phone', 'video', or 'personal'")

    pricing = PRICING[req.session_type]

    # Generate unique booking ID
    raw = f"{req.email}{req.preferred_date}{req.session_type}{datetime.utcnow().isoformat()}"
    booking_id = "NV" + hashlib.sha256(raw.encode()).hexdigest()[:10].upper()

    # Build WhatsApp message
    if req.session_type == "personal":
        session_label = "1-on-1 Master Personal Session (90 min)"
    elif req.session_type == "video":
        session_label = "Video Call (60 min)"
    else:
        session_label = "Phone Call (45 min)"
    wa_message = (
        f"Hello! I'd like to book a numerology consultation.%0A%0A"
        f"Booking ID: {booking_id}%0A"
        f"Session: {session_label}%0A"
        f"Name: {req.name}%0A"
        f"Date: {req.preferred_date}{' at ' + req.preferred_time if req.preferred_time else ''}%0A"
        f"DOB: {req.dob if req.dob else 'Not provided'}%0A"
        f"Focus: {req.focus_area if req.focus_area else 'General reading'}%0A%0A"
        f"Amount: INR {pricing['amount']:,}"
    )
    whatsapp_link = f"https://wa.me/{WHATSAPP_NUMBER}?text={wa_message}"

    # Background task: log booking (replace with DB write in production)
    background_tasks.add_task(log_booking, booking_id, req, pricing)

    return BookingResponse(
        status="requested",
        booking_id=booking_id,
        session_type=req.session_type,
        amount_inr=pricing["amount"],
        message=f"Your booking request {booking_id} has been received. We will confirm via WhatsApp within 2 hours.",
        whatsapp_link=whatsapp_link,
        payment_note="Payment link will be shared on WhatsApp after confirmation. UPI / Card / NetBanking accepted."
    )


@router.get("/slots")
def get_available_slots(date: Optional[str] = None):
    """
    Returns available time slots for booking.
    In production, connect this to your Google Calendar API.
    """
    # Simulated available slots — replace with Google Calendar API in production
    return {
        "status": "ok",
        "date": date or "any",
        "available_slots": [
            "09:00 AM", "11:00 AM", "01:00 PM",
            "03:00 PM", "05:00 PM", "07:00 PM"
        ],
        "note": "All times are IST (Indian Standard Time)"
    }


@router.get("/pricing")
def get_pricing():
    """Returns current consultation pricing."""
    return {
        "phone": {
            "amount_inr": 2499,
            "duration": "45 minutes",
            "includes": [
                "Personal numerological blueprint (6 systems)",
                "Career, love, or financial guidance",
                "Gemstone & remedy prescription",
                "WhatsApp follow-up summary"
            ]
        },
        "video": {
            "amount_inr": 3999,
            "duration": "60 minutes",
            "includes": [
                "Everything in Phone Session",
                "Live Lo Shu Grid visualization",
                "Annual timing roadmap",
                "Recorded session link (optional)"
            ]
        },
        "personal": {
            "amount_inr": 11400,
            "original_price_inr": 24000,
            "duration": "90 minutes",
            "includes": [
                "90-minute private 1-on-1 session with Master Numerologist",
                "Birth Epoch Verification & deep multi-system chart synthesis",
                "Custom hand-crafted remedy plan, yantra & gemstone prescription",
                "30-day direct priority WhatsApp guidance",
                "Comprehensive Deluxe Destiny Dossier PDF report"
            ]
        }
    }


def log_booking(booking_id: str, req: BookingRequest, pricing: dict):
    """
    Log booking to file (replace with PostgreSQL / Neon DB write in production).
    Schema: bookings table in Neon PostgreSQL
    """
    log_entry = {
        "booking_id": booking_id,
        "timestamp": datetime.utcnow().isoformat(),
        "name": req.name,
        "email": req.email,
        "phone": req.phone,
        "session_type": req.session_type,
        "preferred_date": req.preferred_date,
        "preferred_time": req.preferred_time,
        "focus_area": req.focus_area,
        "amount_inr": pricing["amount"],
        "status": "pending"
    }
    try:
        import os
        log_path = os.path.join(os.path.dirname(__file__), "../../data/bookings.jsonl")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
    except Exception as e:
        print(f"[BOOKING LOG ERROR] {e}")
